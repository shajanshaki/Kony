//
//  IUploadableObject.h
//  GenericObject
//
//  Created by Sunil Phani Manne on 10/11/16.
//  Copyright © 2016 Sunil Phani Manne. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "ICommonCapabilities.h"
#import "SyncBatch.h"

@class KSSDKObject;
@class KSSDKObjectRecord;
@class KSUploadResponseMetadata;

@protocol IUploadableObject <ICommonCapabilities>

@required

/**
  @brief This method is used for getting the list of sdk objects to upload
 
  @param error The error thrown while getting upload objects
 
  @param batchParams Dictionary with keys UploadBatchSize, BatchNumber, lastRSNOfPreviousBatch and lastRSNToUploadInTheCurrentSession
 
  @return The list object to upload
 **/
- (NSArray <KSSDKObject *> *) objectsToUpload:(OfflineObjectsError **)error
                                  uploadStats:(SyncBatch *) uploadStats
                                  batchParams:(NSDictionary *)batchParams;
/**
  @brief The method handles the upload response to populate the sdk object
 
  @param uploadedObjects The uploaded objects list from upload response
 
  @param responseMetadata The metadata the came with upload response
 **/
- (void) onObjectUpload:(NSArray<KSSDKObject *> *)uploadedObjects
   withResponseMetadata:(KSUploadResponseMetadata *)responseMetadata;

/**
 @brief This method returns the upload request build for a given object

 @param error The error while building the upload request

 @param uploadStats Capture upload Stats for Sync run.
 
 @param batchParams Dictionary with keys UploadBatchSize, BatchNumber, lastRSNOfPreviousBatch and lastRSNToUploadInTheCurrentSession
 
 @param context contains sync options and query params.
 
 @return The request url, headers and body (Keys: request_headers, url, request_body)
 **/
-(NSDictionary *) createUploadRequest:(OfflineObjectsError **) error
                          uploadStats:(SyncBatch *) uploadStats
                          batchParams:(NSMutableDictionary * __strong *)batchParams
                              context:(NSDictionary <NSString *,id> *)context;

/**
 @brief This method will be used for parsing the upload response of any given object
 
 @param response The string response of upload request
 
 @param error The error thrown while parsing the response
 
 @return Dictionary containing data objects, upload metadata and upload failed objects
        (Keys: failureObjects, dataObjects, metadataObject)
 **/
-(NSDictionary *) parseUploadResponse:(NSString *) response
                                error:(OfflineObjectsError **) error;

@end
