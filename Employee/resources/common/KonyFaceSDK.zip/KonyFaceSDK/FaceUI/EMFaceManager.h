/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import <Foundation/Foundation.h>
#import <EzioMobile/EzioMobile.h>
#import "EMFaceSettings.h"

/**
 * The Facial UI result status enumeration
 */
typedef NS_ENUM(NSUInteger, EMFaceManagerProcessStatus){
    /**
     * The Facial UI operation ended successfully
     */
    EMFaceManagerProcessStatusSuccess,
    
    /**
     * The Facial UI operation ended with an error. The error description will be stored in the faceStatusError variable
     */
    EMFaceManagerProcessStatusFail,
    
    /**
     * The Facial UI operation was canceled by the user
     */
    EMFaceManagerProcessStatusCancel
};


/**
 * The Facial UI public manager used to configure, start verify or enroll operations
 */
@interface EMFaceManager : NSObject

/**
 * The singleton instance of Face UI manager
 * @return EMFaceManager instance
 */
+ (instancetype)sharedInstance;

/**
 * Whether the device supports face authentication (i.e. Front Facing Camera)
 */
@property (readonly) BOOL isSupported;

/**
 * Whether the Service is currently initializing
 * If true, do not invoke API and wait until initialization if finished 
 * See initialize:
 */
@property (readonly) BOOL isInitializing;

/**
 * Whether the service is initialized
 * If false, do not invoke API and call first initialize: method
 */
@property (readonly) BOOL isInitialized;

/**
 * Gets the EMFaceAuthService object used internally
 * @return EMFaceAuthService
 */
@property (readonly) EMFaceAuthService *service;

/**
 * Gets the EMFaceAuthFactory object used internally
 * @return EMFaceAuthFactory
 */
@property (readonly) EMFaceAuthFactory *factory;

/**
 * If any error occured, get the error status upon the last face operation completion, nil otherwise.
 * @return NSString
 */
@property (nonatomic, strong) NSString *faceStatusError;


/** @name Tasks */
#pragma mark - Tasks

/**
 * Initializes and loads the internal face service and resources. 
 * Could be called multiple times.
 * 
 * @warning Must be called in the main thread
 */
- (void)initialize:(void(^)(BOOL success, NSError *error))completion;


/**
 * Starts the Enroll operation. Creates and present modally a EnrollVerifyController on the viewController received.
 * The method call a completion block when over: EMFaceManagerProcessStatusSuccess, EMFaceManagerProcessStatusCancel, EMFaceManagerProcessStatusFail.
 * If EMFaceManagerProcessStatusFail is end, the error description is available in EMFaceManager faceStatusError property.
 *
 * @param viewController a view controller which will present modally the verify operation (Not Null)
 * @param timeout timeout duration of the operation.
 * @param completion A completion block called when the operation is over.
 */
+  (void)enrollWithPresentingViewController:(UIViewController*) viewController
                                    timeout:(NSTimeInterval)timeout
                                 completion:(void(^)(EMFaceManagerProcessStatus))completion;


/**
 * Starts the Verify operation. Creates a EMVerifyViewController and present it modally on the viewController received.
 * The method call a completion block when over: EMFaceManagerProcessStatusSuccess, EMFaceManagerProcessStatusCancel, EMFaceManagerProcessStatusFail.
 * If EMFaceManagerProcessStatusFail is end, the error description is available in EMFaceManager faceStatusError property.
 *
 * @param viewController A view controller which will present modally the verify operation (Not Null)
 * @param authenticatable The authenticatable object
 * @param timeout timeout duration of the operation.
 * @param completion A completion block called when the operation is over.
 */
+ (void)verifyWithPresentingViewController:(UIViewController*)viewController
                           authenticatable:(id<EMAuthenticatable>)authenticatable
                                   timeout:(NSTimeInterval) timeout
                                completion:(void(^)(EMFaceManagerProcessStatus,id<EMFaceAuthInput> authInput))completion;


/**
 * Start the Unenroll operation.
 * The method call a completion block when over: EMFaceManagerProcessStatusSuccess and EMFaceManagerProcessStatusFail.
 * If EMFaceManagerProcessStatusFail is end, the error description is available in EMFaceManager faceStatusError property.
 *
 * @param completionBlock A completion block called when the operation is over.
 */
+ (void)unenrollWithCompletion:(void(^)(EMFaceManagerProcessStatus))completionBlock;

@end
