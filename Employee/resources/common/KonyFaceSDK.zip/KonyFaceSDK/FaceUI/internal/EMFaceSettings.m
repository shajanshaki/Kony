/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMFaceSettings.h"

@interface EMFaceSettings()
//Fix out of ranges settings
- (void) fixValues;

@end

@implementation EMFaceSettings

+ (instancetype)sharedInstance {
    static dispatch_once_t once;
    static id sharedInstance;
    dispatch_once(&once, ^
                  {
                      sharedInstance = [self new];
                      [sharedInstance resetDefault];
                  });
    return sharedInstance;
}

- (void) setQualityThreshold:(int)qualityThreshold {
    _qualityThreshold = qualityThreshold;
    [self fixValues];
}

- (void) setLivenessThreshold:(int)livenessThreshold {
    _livenessThreshold = livenessThreshold;
    [self fixValues];
}

- (void) setLivenessBlinkTimeout:(int)livenessBlinkTimeout {
    _livenessBlinkTimeout = livenessBlinkTimeout;
    [self fixValues];
}

- (void) setMatchingThreshold:(int)matchingThreshold {
    _matchingThreshold = matchingThreshold;
    [self fixValues];
}

- (void) setNumberOfFramesToEnroll:(int)numberOfFramesToEnroll {
    _numberOfFramesToEnroll = numberOfFramesToEnroll;
    [self fixValues];
}


- (void) setVerifierFaceCaptureMode:(EMFaceCaptureMode)verifierFaceCaptureMode {
    _verifierFaceCaptureMode = verifierFaceCaptureMode;
}

- (void) fixValues {
    if(_livenessThreshold<0) {
        _livenessThreshold = 0;
    }
    else if(_livenessThreshold>100) {
        _livenessThreshold = 100;
    }
    
    if(_qualityThreshold<0) {
        _qualityThreshold = 0;
    }
    else if(_qualityThreshold>100) {
        _qualityThreshold = 100;
    }
    
    if(_matchingThreshold<0) {
        _matchingThreshold = 0;
    }
    else if(_matchingThreshold>72) {
        _matchingThreshold = 72;
    }
    
    if(_livenessBlinkTimeout<0) {
        _livenessBlinkTimeout = 0;
    }
    else if(_livenessBlinkTimeout>100000) {
        _livenessBlinkTimeout = 100000;
    }
    
    if(_numberOfFramesToEnroll < 1){
        _numberOfFramesToEnroll = 1;
    } else if(_numberOfFramesToEnroll > 20){
         _numberOfFramesToEnroll = 20;
    }


    
}

- (void) resetDefault {
    self.livenessThreshold = DEFAULT_LIVENESS_THRESHOLD;
    self.qualityThreshold = DEFAULT_QUALITY_THRESHOLD;
    self.matchingThreshold = DEFAULT_MATCHING_THRESHOLD;
    self.livenessBlinkTimeout = DEFAULT_LIVENESS_BLINK_TIMEOUT;
    self.numberOfFramesToEnroll = DEFAULT_NUMBER_FRAME_TO_ENROLL;
    self.verifierFaceCaptureMode = DEFAULT_VERIFIER_FACE_CAPTURE_MODE;;
    
}
@end
