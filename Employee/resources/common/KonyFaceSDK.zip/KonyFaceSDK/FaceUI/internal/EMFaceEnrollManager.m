/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMFaceEnrollManager.h"
#import "EMFaceManager.h"

@interface EMFaceEnrollManager() {
    int indexOfFrameReceived;
    int nbOfFrameUse;
    BOOL gotFace;
    BOOL userIsReady;
}

@property id<EMFaceAuthEnroller> enroller;
@property EMFaceAuthEnrollerSettings* enrollerSettings;
@property EMFaceAuthFactory* factory;

@end

@implementation EMFaceEnrollManager

+ (instancetype)sharedInstance
{
    static dispatch_once_t once;
    static id sharedInstance;
    dispatch_once(&once, ^{
        sharedInstance = [[EMFaceEnrollManager alloc] init];
    });
    
    return sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
       _factory = [[EMFaceManager sharedInstance] factory];
        self.enrollerSettings = [_factory createFaceAuthEnrollerSettings];
        [self updateEnrollerWithSettings];
        userIsReady = NO;
        gotFace = NO;
    }
    return self;
}


- (void)enroller:(id<EMFaceAuthEnroller>)enroller didUpdateFaceAuthFrameEvent:(id<EMFaceAuthFrameEvent>)frameEvent
{
    [super handleUIWithframeReceived:frameEvent];
    
        if(![self containsFaceWithFrameEvent:frameEvent]){
            [[self delegate] stepDidChange:EMFaceUIDelegateStepEnrollWaitFace];
        }else if([self containsFaceWithFrameEvent:frameEvent]){
            if(!userIsReady){
                [[self delegate] stepDidChange:EMFaceUIDelegateStepWaitStart];
            } else {
                [[self delegate] stepDidChange:EMFaceUIDelegateStepAddFace];
            }
        }

}

- (void)startEnrollmentWithDelegate:(id) sender timeout:(NSTimeInterval)timeout completionHandler:(void (^)(EMStatus status)) handler
{
    [self updateEnrollerWithSettings];
    userIsReady = NO;

    self.delegate = sender;
    [self.enroller setFaceAuthEnrollerDelegate:self];
    
    CGFloat previousBrightness = [[UIScreen mainScreen] brightness];
    [[UIScreen mainScreen] setBrightness:1.0f];
    
    /* Timeout is in milliseconds */
    int timeoutMilliseconds = (int)timeout * 1000;
    
    [self.enroller enroll:timeoutMilliseconds withCompletion:(^(BOOL success,id<EMFaceAuthEnroller> callbackEnroller,NSError *error){
        [[UIScreen mainScreen] setBrightness:previousBrightness];
        if( success){
            [[self delegate] stepDidChange:EMFaceUIDelegateStepSuccess];
            handler(EM_STATUS_AUTHENTICATION_FACIAL_SUCCESS);
        }else{
             [[self delegate] stepDidChange:EMFaceUIDelegateStepError];
            handler((EMStatus)[error code]);
        }
         [callbackEnroller removeFaceAuthEnrollerDelegate];
    })];
}

- (void) cancelFaceOperation {
    [self.enroller cancel];
    [[self delegate] stepDidChange:EMFaceUIDelegateStepCancel];
    [self.enroller removeFaceAuthEnrollerDelegate];
}

/* Start and End of Capturing Process */
- (void)enrollerDidStartCapturing:(id<EMFaceAuthEnroller>)enroller{
        [self stepDidChange:EMFaceUIDelegateStepEnrollWaitFace];
    
}

/* End of Capturing Process */
- (void)enrollerDidEndCapturing:(id<EMFaceAuthEnroller>)enroller{
    [self stepDidChange:EMFaceUIDelegateStepProcessing];
    userIsReady = NO;
}


/* Confirm if face to be added */
- (BOOL)enroller:(id<EMFaceAuthEnroller>)enroller shouldAddFaceEvent:(id<EMFaceAuthFrameEvent>)frameEvent withIndex:(NSUInteger)index{
    
    BOOL shouldCapture = [self containsFaceWithFrameEvent:frameEvent] && userIsReady;
    if (shouldCapture) {
        return YES;
    }
    
    userIsReady = NO;
    
    return NO;
}

/*  Unenroll */
- (void) unenrollWithCompletionHandler:(void(^)(BOOL success, NSError *error))completion{
    [self.enroller unenrollWithCompletion:^(BOOL unenrollSuccess,NSError *error){
        completion(unenrollSuccess,error);
        userIsReady = NO;
    }];
}


-(void)userIsReady{
    userIsReady = YES;
}

- (void) updateEnrollerWithSettings {
    [self.enrollerSettings setQualityThreshold:[[EMFaceSettings sharedInstance] qualityThreshold]];
    [self.enrollerSettings setLivenessThreshold:[[EMFaceSettings sharedInstance] livenessThreshold]];
    [self.enrollerSettings setNumberOfFramesToEnroll:[[EMFaceSettings sharedInstance] numberOfFramesToEnroll]];
    [self.enrollerSettings setCountdownToCapture:0];
    self.enroller = [_factory createFaceAuthEnrollerWithSettings:_enrollerSettings];
}


#pragma mark - EMFaceAuthLicenseBuilderDelegate

- (BOOL)licenseBuilderShouldFetchLicenseFromServer:(EMFaceAuthLicenseBuilder *)licenseBuilder
{
    return YES;
}

- (void)licenseBuilderWillStartFetchingLicenseFromServer:(EMFaceAuthLicenseBuilder *)licenseBuilder
{
    [(id<EMFaceAuthLicenseBuilderDelegate>)self.delegate licenseBuilderWillStartFetchingLicenseFromServer:licenseBuilder];
}
- (void)licenseBuilder:(EMFaceAuthLicenseBuilder *)licenseBuilder didEndFetchingLicenseWithStatus:(BOOL)status error:(NSError *)error
{
    [(id<EMFaceAuthLicenseBuilderDelegate>)self.delegate licenseBuilder:licenseBuilder didEndFetchingLicenseWithStatus:status error:error];
}


@end
