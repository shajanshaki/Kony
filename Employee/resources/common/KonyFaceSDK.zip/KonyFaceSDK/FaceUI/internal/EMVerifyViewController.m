/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMVerifyViewController.h"
#import "EMFaceVerifyManager.h"
#import "EMFaceMessageHelper.h"
#import "EMFaceManager.h"

@interface EMVerifyViewController (){
}

@end

@implementation EMVerifyViewController{
    UIAlertView *waitingAlert;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    [self.overContainer setBorderWith:20.0f];
    [self.overContainer setAnimationDuration:2.f];
}

- (void) viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self runVerify];
}

- (void) runVerify {
    
    [[EMFaceVerifyManager sharedInstance] verifyWithAuthenticable:self.authenticatable
                                                       delegate:self
                                                        timeout:self.timeout
                                                     completion:(^(id<EMFaceAuthInput> authInput,NSError *error){
        if(!error){
            [self stepDidChange:EMFaceUIDelegateStepSuccess];
            if (self.completionHandler) {
                self.completionHandler(EMFaceManagerProcessStatusSuccess,authInput);
            }
        }else{
            EMStatus status = (EMStatus) [error code];
            switch(status){
                case EM_STATUS_AUTHENTICATION_FACIAL_CANCELED: {
                    if (self.completionHandler) {
                        self.completionHandler(EMFaceManagerProcessStatusCancel,nil);
                    }
                    if (self.autoDismissWhenComplete) {
                        [self dismissViewControllerAnimated:YES completion:nil];
                    }
                    break;
                }
                default:
                {
                    [[EMFaceManager sharedInstance] setFaceStatusError:[error localizedDescription]];
                    self.completionHandler(EMFaceManagerProcessStatusFail,nil);
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:[EMFaceMessageHelper getErrorMessageForErrorCode:status] preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:RetryButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                        [self runVerify];
                    }]];
                    [alert addAction:[UIAlertAction actionWithTitle:CancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                        [self cancelProcess:nil];
                    }]];

                    [self presentViewController:alert animated:true completion:^{}];
                    break;
                }
            }
        }
    })];
}

- (IBAction)startProcess:(id)sender {
    [self runVerify];
}

- (IBAction)cancelProcess:(id)sender {
    [[EMFaceVerifyManager sharedInstance] cancelFaceOperation];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void) stepDidChange:(EMFaceUIDelegateStep)step {
    [super stepDidChange:step];
}

- (void)licenseBuilderWillStartFetchingLicenseFromServer:(EMFaceAuthLicenseBuilder *)licenseBuilder
{
    waitingAlert = [[UIAlertView alloc] initWithTitle:@"Please Wait"
                                              message:@"Fetching license from server..."
                                             delegate:nil
                                    cancelButtonTitle:@"OK"
                                    otherButtonTitles:nil, nil];
    [waitingAlert show];
}
- (void)licenseBuilder:(EMFaceAuthLicenseBuilder *)licenseBuilder didEndFetchingLicenseWithStatus:(BOOL)status error:(NSError *)error
{
    [waitingAlert dismissWithClickedButtonIndex:waitingAlert.cancelButtonIndex animated:YES];
}


@end
