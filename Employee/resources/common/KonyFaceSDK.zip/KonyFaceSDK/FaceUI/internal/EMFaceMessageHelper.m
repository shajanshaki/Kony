/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMFaceMessageHelper.h"

@implementation EMFaceMessageHelper

    NSString* const OkButtonTitle = @"OK";
    NSString* const RetryButtonTitle = @"RETRY";
    NSString* const StartButtonTitle = @"START";
    NSString* const ContinueButtonTitle = @"CONTINUE";
    NSString* const CancelButtonTitle = @"CANCEL";

    NSString* const VerificationFaceOutTitle = @"Please position your face in the center of the circle";
    NSString* const VerificationBlinkTitle = @"BLINK YOUR EYES !";
    NSString* const VerificationKeepStillTitle = @"KEEP STILL !";

    NSString* const ErrorUnknown = @"An error has occurred. You may retry again later";
    NSString* const ErrorBadQuality = @"We are not able to capture your face. Please make sure to position your face in front of the camera and to have good lighting conditions";
    NSString* const ErrorCameraNotFound = @"We couldn't detect or use a camera on your device.";
    NSString* const ErrorMatchNotFound = @"We are sorry but your face does not seem to match the one registered.";
    NSString* const ErrorUserReenollmentNeeded = @"Sorry but you need to enroll again !";
    NSString* const ErrorLivenessCheckFailed = @"We could not detect that you blinked. Please try again to blink and make sure to have good lighting conditions";
    NSString* const ErrorTimedOut = @"We could not detect your face. Please try again and make sure to have good lighting conditions";
    NSString* const ErrorUserNotFound = @"The user you selected does not exist !";
    NSString* const ErrorLicenseError = @"License Error. Either the license is not set or the license is invalid.";


    + (NSString*) getErrorMessageForErrorCode:(EMStatus) error {
        if (error == EM_STATUS_AUTHENTICATION_FACIAL_ERROR || error == EM_STATUS_AUTHENTICATION_FACIAL_ALREADY_EXTRACTING) {
            return ErrorTimedOut;
        } else if (error == EM_STATUS_AUTHENTICATION_FACIAL_BAD_QUALITY) {
            return ErrorBadQuality;
        } else if (error == EM_STATUS_AUTHENTICATION_FACIAL_CAMERA_NOT_FOUND) {
            return ErrorCameraNotFound;
        } else if (error == EM_STATUS_AUTHENTICATION_FACIAL_MATCH_NOT_FOUND) {
            return ErrorMatchNotFound;
        } else if (error == EM_STATUS_AUTHENTICATION_FACIAL_USER_NOT_FOUND) {
            return ErrorUserNotFound;
        } else if (error == EM_STATUS_AUTHENTICATION_FACIAL_USER_REENROLL_NEEDED) {
            return ErrorUserReenollmentNeeded;
        } else if (error == EM_STATUS_AUTHENTICATION_FACIAL_LIVENESS_CHECK_FAILED) {
            return ErrorLivenessCheckFailed;
        } else if (error == EM_STATUS_AUTHENTICATION_FACIAL_TIMEOUT) {
            return ErrorTimedOut;
        }else if (error == EM_STATUS_AUTHENTICATION_LICENSE_ERROR) {
            return ErrorLicenseError;
        }
        return ErrorUnknown;
    }
@end
