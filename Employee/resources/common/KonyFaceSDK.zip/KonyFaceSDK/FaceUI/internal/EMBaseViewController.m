/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMBaseViewController.h"
#import "EMFaceMessageHelper.h"
#import "EMFaceManager.h"
#import "EMFaceConstant.h"

@interface EMBaseViewController () <EMFaceAuthUIDelegate>
@end

@implementation EMBaseViewController
+(UIColor *) red         { return [UIColor colorWithRed:226.0/255.0 green:35.0/255.0 blue:0.0/255.0 alpha:1.0];}
+(UIColor *) green { return [UIColor colorWithRed:130.0/255.0 green:188.0/255.0 blue:0.0/255.0 alpha:1.0];}
+(UIColor *) textActive { return [UIColor colorWithRed:64.0/255.0 green:64.0/255.0 blue:64.0/255.0 alpha:1.0];}
+(UIColor *) textInactive { return [UIColor colorWithRed:167.0/255.0 green:169.0/255.0 blue:171.0/255.0 alpha:1.0];}

- (void) setupButton:(UIButton*) button {
    [button setTitleColor:[EMBaseViewController textActive] forState:UIControlStateNormal];
    [button setTitleColor:[EMBaseViewController textInactive] forState:UIControlStateDisabled];
    button.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    button.layer.shadowOpacity = 0.5f;
    button.layer.shadowOffset = CGSizeZero;
    button.layer.shadowRadius = 2.0f;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.timeout = 60;
    UIImage *image = [UIImage imageNamed:navigationBarLogoRessourceName inBundle:[NSBundle faceUIBundle] compatibleWithTraitCollection:nil];
    self.navItem.titleView = [[UIImageView alloc] initWithImage:image];
    self.faceViewContainer.transform = CGAffineTransformMakeScale(-1, 1);
    [self initialStep];
}

- (void) initialStep {
    [self setupButton:self.startButton];
    [self setupButton:self.cancelButton];
    
    [self.startButton setTitle:StartButtonTitle forState:UIControlStateNormal];
    [self.cancelButton setTitle:CancelButtonTitle forState:UIControlStateNormal];
    
    [self setupStartButtonWithHidden:YES andEnable:NO];
    [self setupStatusLabelWithText:@" " andBlinkLabel:@" "];

    self.faceViewContainer.layer.borderColor = [EMBaseViewController red].CGColor;
    self.faceViewContainer.layer.borderWidth = 4.0f;
    
    self.successView.hidden = YES;
}


- (void) viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    self.faceViewContainer.layer.cornerRadius = self.faceViewContainer.bounds.size.width / 2.0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void) imageDidUpdate:(UIImage *)image {
    [self.overContainer setHidden:NO];
    [self.faceViewContainer setFaceImage:image];
}


- (void) stepDidChange:(EMFaceUIDelegateStep)step {
    switch (step) {
        case EMFaceUIDelegateStepWaitStart: {
            [self configureOverContainerWithHidden:NO andAnimation:NO];
            [self setupStartButtonWithHidden:NO andEnable:YES];
            [self setupStatusLabelWithText:@" " andBlinkLabel:@" "];
            self.faceViewContainer.layer.borderColor = [EMBaseViewController green].CGColor;
            break;
        }
        case EMFaceUIDelegateStepProcessing: {
            [self configureOverContainerWithHidden:NO andAnimation:YES];
            [self setupStartButtonWithHidden:YES andEnable:NO];
            [self setupStatusLabelWithText:@" " andBlinkLabel:@" "];
            self.faceViewContainer.layer.borderColor = [EMBaseViewController green].CGColor;
            break;
        }
        
        case EMFaceUIDelegateStepSuccess: {
             [self configureOverContainerWithHidden:YES andAnimation:NO];
            [self setupStartButtonWithHidden:YES andEnable:NO];
            [self displaySuccessView];
            [self setupStatusLabelWithText:@" " andBlinkLabel:@" "];
            break;
        }
        case EMFaceUIDelegateStepError: {
            [self setupStartButtonWithHidden:NO andEnable:NO];
            [self configureOverContainerWithHidden:NO andAnimation:NO];
            [self setupStatusLabelWithText:@" " andBlinkLabel:@" "];
            self.faceViewContainer.layer.borderColor = [EMBaseViewController red].CGColor;
            break;
        }
        case EMFaceUIDelegateStepCancel: {
            [self setupStartButtonWithHidden:YES andEnable:NO];
            [self configureOverContainerWithHidden:YES andAnimation:NO];
            [self setupStatusLabelWithText:@" " andBlinkLabel:@" "];
            break;
        }
        
                
        case EMFaceUIDelegateStepEnrollWaitFace: {
            [self setupStartButtonWithHidden:NO andEnable:NO];
            [self configureOverContainerWithHidden:NO andAnimation:NO];
            self.faceViewContainer.layer.borderColor = [EMBaseViewController red].CGColor;
            [self setupStatusLabelWithText:VerificationFaceOutTitle.uppercaseString andBlinkLabel:@" "];
            break;
        }
            
        case EMFaceUIDelegateStepAddFace: {
            [self setupStartButtonWithHidden:NO andEnable:NO];
            [self configureOverContainerWithHidden:NO andAnimation:NO];
            [self setupStatusLabelWithText:@"" andBlinkLabel:@" "];
            self.faceViewContainer.layer.borderColor = [EMBaseViewController green].CGColor;
            break;
        }
            
        case EMFaceUIDelegateStepBlink: {
            [self setupStartButtonWithHidden:YES andEnable:NO];
            [self configureOverContainerWithHidden:NO andAnimation:NO];
            [self setupStatusLabelWithText:@" " andBlinkLabel:VerificationBlinkTitle.uppercaseString];
            self.faceViewContainer.layer.borderColor = [EMBaseViewController green].CGColor;
            break;
        }
        case EMFaceUIDelegateStepKeepStill: {
            [self setupStartButtonWithHidden:YES andEnable:NO];
            [self configureOverContainerWithHidden:NO andAnimation:NO];
            [self setupStatusLabelWithText:@" " andBlinkLabel:VerificationKeepStillTitle.uppercaseString];
            self.faceViewContainer.layer.borderColor = [EMBaseViewController green].CGColor;
            break;
        }
        default:
            break;
    }
}

- (IBAction)cancelProcess:(id)sender {
}

- (IBAction)startProcess:(id)sender {
}


#pragma private functions
-(void) configureOverContainerWithHidden:(BOOL)isHidden andAnimation:(BOOL)isAnimated
{
    [self.overContainer setHidden:isHidden];
    if (isAnimated) {
        [self.overContainer startAnimating];
    } else {
        [self.overContainer stopAnimating];
    }
}

-(void) setupStartButtonWithHidden:(BOOL)isHidden andEnable:(BOOL)isEnabled
{
    self.startButton.hidden = isHidden;
    self.startButton.enabled = isEnabled;
}

-(void) setupStatusLabelWithText:(NSString *)statusLabel andBlinkLabel:(NSString *)blinkLabel
{
    [self.statusLabel setText:statusLabel];
    [self.blinkLabel setText:blinkLabel];
    
}

-(void) displaySuccessView {
    self.successView.hidden = NO;
    [self.cancelButton setTitle:ContinueButtonTitle forState:UIControlStateNormal];
    [self.cancelButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.cancelButton setBackgroundImage:[UIImage imageNamed:continueButtonRessourceName inBundle:[NSBundle faceUIBundle] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
}
@end
