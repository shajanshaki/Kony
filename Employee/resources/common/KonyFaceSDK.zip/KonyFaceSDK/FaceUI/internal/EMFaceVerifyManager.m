/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMFaceVerifyManager.h"
#import "EMFaceManager.h"

@interface EMFaceVerifyManager() {
    BOOL didAskToBlink;
    BOOL didBlink;
    BOOL gotFace;
    EMFaceAuthLivenessAction previousAction;
}

    @property EMFaceAuthVerifierSettings *verifSettings;
    @property id<EMFaceAuthVerifier> verifier;
    @property id<EMFaceAuthInput> faceAuthInput;
    @property NSError * faceAuthError;
    @property EMFaceAuthFactory * factory;
@end

@implementation EMFaceVerifyManager

+ (instancetype)sharedInstance
{
    static dispatch_once_t once;
    static id sharedInstance;
    dispatch_once(&once, ^{
        sharedInstance = [[EMFaceVerifyManager alloc] init];
    });
    
    return sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _factory = [[EMFaceManager sharedInstance] factory];
        self.verifSettings = [_factory createFaceAuthVerifierSettings];
        [self updateVerifierWithSettings];
    }

    return self;
}

- (void)verifier:(id<EMFaceAuthVerifier>)verifier didUpdateFaceAuthFrameEvent:(id<EMFaceAuthFrameEvent>)frameEvent
{
    [super handleUIWithframeReceived:frameEvent];
    
    EMFaceAuthLivenessAction currentAction =[frameEvent livenessAction];
    
    bool nowHaveFace = [self containsFaceWithFrameEvent:frameEvent];

    if (!nowHaveFace){
        [self stepDidChange:EMFaceUIDelegateStepVerifyWaitFace];
    } else {
        if(currentAction==EMFaceAuthLivenessActionBlink){
            [self stepDidChange:EMFaceUIDelegateStepBlink];
        }else if(currentAction==EMFaceAuthLivenessActionKeepStill){
            [self stepDidChange:EMFaceUIDelegateStepKeepStill];
        } else {
            [self stepDidChange:EMFaceUIDelegateStepProcessing];
        }
    }
}

- (void) verifyWithAuthenticable:(id<EMAuthenticatable>)authenticatable
                        delegate:(id<EMFaceAuthUIDelegate>)delegate
                         timeout:(NSTimeInterval)timeout
                      completion:(void (^)(id<EMFaceAuthInput> authInput,NSError *error))completion;
{
    [self updateVerifierWithSettings];
    [self stepDidChange:EMFaceUIDelegateStepVerifyWaitFace];
    gotFace = NO;
    previousAction = EMFaceAuthLivenessActionNoLiveAction;
    
    self.delegate = delegate;
    [self.verifier setFaceAuthVerifierDelegate:self];
    CGFloat previousBrightness = [[UIScreen mainScreen] brightness];
    [[UIScreen mainScreen] setBrightness:1.0f];
    
    int timeoutMilliSeconds = (int)timeout * 1000;
    
    [self.verifier authenticateUser:authenticatable
                        withTimeOut:timeoutMilliSeconds
                  completionHandler:^(id<EMFaceAuthInput> faceAuthInput, NSError *authError){
                      [self.verifier removeFaceAuthVerifierDelegate];
                      self.delegate = nil;
                      completion(faceAuthInput,authError);
                      [[UIScreen mainScreen] setBrightness:previousBrightness];
                  }];
}

- (void) cancelFaceOperation
{
    [self.verifier cancel];
    [self.verifier removeFaceAuthVerifierDelegate];
    self.delegate = nil;
}

- (void) updateVerifierWithSettings {
    [self.verifSettings setFaceCaptureMode:[[EMFaceSettings sharedInstance] verifierFaceCaptureMode]];
    [self.verifSettings setQualityThreshold:[[EMFaceSettings sharedInstance] qualityThreshold]];
    [self.verifSettings setLivenessThreshold:[[EMFaceSettings sharedInstance] livenessThreshold]];
    [self.verifSettings setMatchingThreshold:[[EMFaceSettings sharedInstance] matchingThreshold]];
    [self.verifSettings setLivenessBlinkTimeout:[[EMFaceSettings sharedInstance] livenessBlinkTimeout]];
    self.verifier = [_factory createFaceAuthVerifierWithSettings:_verifSettings];
}

#pragma mark - EMFaceAuthLicenseBuilderDelegate

- (BOOL)licenseBuilderShouldFetchLicenseFromServer:(EMFaceAuthLicenseBuilder *)licenseBuilder
{
    return YES;
}

- (void)licenseBuilderWillStartFetchingLicenseFromServer:(EMFaceAuthLicenseBuilder *)licenseBuilder
{
    [(id<EMFaceAuthLicenseBuilderDelegate>)self.delegate licenseBuilderWillStartFetchingLicenseFromServer:licenseBuilder];
}
- (void)licenseBuilder:(EMFaceAuthLicenseBuilder *)licenseBuilder didEndFetchingLicenseWithStatus:(BOOL)status error:(NSError *)error
{
    [(id<EMFaceAuthLicenseBuilderDelegate>)self.delegate licenseBuilder:licenseBuilder didEndFetchingLicenseWithStatus:status error:error];
}


@end
