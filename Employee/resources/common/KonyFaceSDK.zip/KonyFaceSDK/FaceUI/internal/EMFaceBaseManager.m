/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMFaceBaseManager.h"

@interface EMFaceBaseManager() {
    UIImage * faceImage; // Returned by Ezio EMFaceFrameEvent
}
@end

@implementation EMFaceBaseManager

- (void) handleUIWithframeReceived:(id<EMFaceAuthFrameEvent>)event {
    
    @autoreleasepool {
        faceImage = [event image];
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.delegate imageDidUpdate:faceImage];
    });
}


// Helper function to check if face is detected
- (BOOL) containsFaceWithFrameEvent:(id<EMFaceAuthFrameEvent>) event {
    BOOL hasFace = YES;
    CGRect faceRect = [event imageBounds];
    
    if(CGRectIsEmpty(faceRect)) {
        hasFace = NO;
    }

    return hasFace;
}


- (void) stepDidChange:(EMFaceUIDelegateStep) step {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.delegate stepDidChange:step];
    });
}

+(NSString*)faceStatusToNSString:(EMStatus)status{
    
    NSString *result;
    
    switch (status) {
            
        case EM_STATUS_AUTHENTICATION_FACIAL_NONE:
            result = @"None";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_SUCCESS:
            result =@"Success";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_REQUIRED_LIVE_ACTION:
            result =@"Required live action";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_ERROR:
            result =@"Error";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_TIMEOUT:
            result=@"Timeout";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_BAD_QUALITY:
            result=@"Bad quality";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_CAMERA_NOT_FOUND:
            result=@"Camera not found";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_CANCELED:
            result=@"Canceled";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_MATCH_NOT_FOUND:
            result =@"Match not found";
            break;
        case EM_STATUS_AUTHENTICATION_FACIAL_USER_EXISTS:
            result=@"User exist";
            break;
            
        case EM_STATUS_AUTHENTICATION_FACIAL_USER_NOT_FOUND:
            result=@"User not found";
            break;
            
        case EM_STATUS_AUTHENTICATION_FACIAL_USER_REENROLL_NEEDED:
            result=@"Re enroll needed";
            break;
            
        case EM_STATUS_AUTHENTICATION_FACIAL_ALREADY_EXTRACTING:
            result=@"Already extracting";
            break;
            
        case EM_STATUS_AUTHENTICATION_FACIAL_LIVENESS_CHECK_FAILED:
            result=@"Liveness check failed";
            break;
            
        case EM_STATUS_AUTHENTICATION_FACIAL_FACE_NOT_FOUND:
            result=@"Face not found";
            break;
            
        default:
            result=@"Error";
            break;
    }
    
    return result;
}

- (void) cancelFaceOperation{
}
@end
