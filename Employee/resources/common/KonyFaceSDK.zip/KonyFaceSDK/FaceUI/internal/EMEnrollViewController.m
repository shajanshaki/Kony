/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMEnrollViewController.h"
#import "EMFaceEnrollManager.h"
#import "EMFaceMessageHelper.h"

@interface EMEnrollViewController()<EMFaceAuthLicenseBuilderDelegate> {
}


@end

@implementation EMEnrollViewController{
    UIAlertView *waitingAlert;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view.
    [self.overContainer setBorderWith:24.0f];
    [self.overContainer setAnimationDuration:5.f];
}

- (void) stepDidChange:(EMFaceUIDelegateStep)step {
    [super stepDidChange:step];
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self doEnroll];
}

- (void)doEnroll
{
    if ([[EMFaceManager sharedInstance] isInitialized]) {
        [[EMFaceEnrollManager sharedInstance] startEnrollmentWithDelegate:self timeout:self.timeout completionHandler:^(EMStatus status){
            switch (status) {
                case EM_STATUS_AUTHENTICATION_FACIAL_SUCCESS:
                    NSLog(@"Executing success handler");
                    self.completionHandler(EMFaceManagerProcessStatusSuccess);
                    break;
                case EM_STATUS_AUTHENTICATION_FACIAL_CANCELED:
                    self.completionHandler(EMFaceManagerProcessStatusCancel);
                    break;
                default: {
                    [[EMFaceManager sharedInstance] setFaceStatusError:[EMFaceBaseManager faceStatusToNSString:status]];
                    self.completionHandler(EMFaceManagerProcessStatusFail);
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"" message:[EMFaceMessageHelper getErrorMessageForErrorCode:status] preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:RetryButtonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                         [self performSelector:@selector(doEnroll) withObject:nil afterDelay:1.0f];
                    }]];
                    [alert addAction:[UIAlertAction actionWithTitle:CancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
                        [self cancelProcess:nil];
                    }]];

                    [self presentViewController:alert animated:true completion:^{
                        [self stepDidChange:EMFaceUIDelegateStepWaitStart];
                    }];
                    break;
                }
            }
            
        }];
    } else {
        [self performSelector:@selector(doEnroll) withObject:nil afterDelay:1.0f];
    }
}

- (IBAction)startProcess:(id)sender
{
    [[EMFaceEnrollManager sharedInstance] userIsReady];
}

- (IBAction)cancelProcess:(id)sender
{
    [[EMFaceEnrollManager sharedInstance] cancelFaceOperation];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)licenseBuilderWillStartFetchingLicenseFromServer:(EMFaceAuthLicenseBuilder *)licenseBuilder
{
    waitingAlert = [[UIAlertView alloc] initWithTitle:@"Please Wait"
                                              message:@"Fetching license from server..."
                                             delegate:nil
                                    cancelButtonTitle:@"OK"
                                    otherButtonTitles:nil, nil];
    [waitingAlert show];
}
- (void)licenseBuilder:(EMFaceAuthLicenseBuilder *)licenseBuilder didEndFetchingLicenseWithStatus:(BOOL)status error:(NSError *)error
{
    [waitingAlert dismissWithClickedButtonIndex:waitingAlert.cancelButtonIndex animated:YES];
}


@end
