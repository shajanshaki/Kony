/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import <Foundation/Foundation.h>
#import <EzioMobile/EzioMobile.h>

/**
 * @discussion Face UI SDK protocol to listen all the UI modification to present to the user.
 */
@protocol EMFaceAuthUIDelegate <NSObject>

/**
 * Face UI SDK Step enumeration. Describes each step the Face UI could be in
 */
typedef NS_ENUM(NSUInteger, EMFaceUIDelegateStep)
{
    /**
     * Waiting for a face to be positioned in front of the camera
     */
    EMFaceUIDelegateStepEnrollWaitFace,
    
    /**
     * Waiting for a face to be positioned in front of the camera
     */
    EMFaceUIDelegateStepVerifyWaitFace,
    
    /**
     * Got a face in front of the camera (enrolment) and user already starts real enrollment
     */
    EMFaceUIDelegateStepAddFace,

    
    /**
     * Waiting for end-user start
     */
    EMFaceUIDelegateStepWaitStart,
    
    /**
     * Processing step of the current operation
     */
    EMFaceUIDelegateStepProcessing,
    
    /**
     * Waiting the end-user to blink during verify operation
     */
    EMFaceUIDelegateStepBlink,
    
    /**
     * Waiting the end-user to keep still during verify operation
     */
    EMFaceUIDelegateStepKeepStill,
    
    /**
     * Step to handle the UI of a sucessfully ended operation
     */
    EMFaceUIDelegateStepSuccess,
    
    /**
     * Step to handle the UI where the operation ended with an error
     */
    EMFaceUIDelegateStepError,
    
    /**
     * Step to handle the UI where the user canceled the operation
     */
    EMFaceUIDelegateStepCancel,
};

/**
 * Delegate method which receives the image from the camera
 * @param image the image to set on a UIImageView
 */
- (void)imageDidUpdate:(UIImage*)image;


/**
 * Delegate method to handle a new step during the Verify or Enroll operation
 * @param step new step of the operation
 */
- (void)stepDidChange:(EMFaceUIDelegateStep)step;


@end


/**
 * Base Manager of the Face UI SDK processes, Enroll and Verify. It handles all the commun elements between the two processes
 */

@interface EMFaceBaseManager : NSObject

/**
 * Face Listener delegate property
 */
@property (nonatomic, weak) id <EMFaceAuthUIDelegate> delegate;


/**
 * Helper method to detect if the current face frame event has a face on it.
 * @param event current face frame event
 * @return return YES if the event has a face, NO otherwise
 */
- (BOOL)containsFaceWithFrameEvent:(id<EMFaceAuthFrameEvent>)event;


/**
 * Helper method to handle the step modification during a operation
 * @param step current step
 */
- (void)stepDidChange:(EMFaceUIDelegateStep)step;

/**
 * Helper methode to display the current face status as a BSString
 * @param status the current face status
 * @return the string of the current face status
 */
+(NSString*)faceStatusToNSString:(EMStatus)status;


/* !
 * Update video view with the new frame received
 * @param event New frame event received
 */
- (void)handleUIWithframeReceived:(id<EMFaceAuthFrameEvent>)event;

/* !
 * Cancel operation handler
 * To be overrided by children class
 */
- (void)cancelFaceOperation;

@end
