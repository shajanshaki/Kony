/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import "EMFaceBaseManager.h"


/**
 * @discussion Face UI SDK mananger to handle the enroll operation
 */
// 
@interface EMFaceEnrollManager : EMFaceBaseManager <EMFaceAuthEnrollerDelegate>


/**
 * Create the singleton instance of the Face Enroll Operation manager
 * @return EMFaceEnrollManager
 */
+ (instancetype)sharedInstance;

/**
 * Unenroll a previously enrolled user
 * @param completion The completion block for unenroll
 */
- (void)unenrollWithCompletionHandler:(void(^)(BOOL success, NSError *error))completion;

/**
 * Method to start an enrollment of a specific user with a maximum timeout.
 * @param sender the delegate which will handles the UI of the enroll operation
 * @param timeout the maximum time (in ms) before canceling the operation, default 60 seconds
 */
- (void)startEnrollmentWithDelegate:(id)sender
                            timeout:(NSTimeInterval)timeout
                  completionHandler:(void(^)(EMStatus status))handler;

/* Method to inform SDK that user is ready to be captured */
- (void)userIsReady;
@end
