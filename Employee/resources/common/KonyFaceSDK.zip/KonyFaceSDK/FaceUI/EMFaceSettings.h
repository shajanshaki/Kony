/* -----------------------------------------------------------------------------
 *
 *     Copyright (c) 2016  -  GEMALTO DEVELOPMENT - R&D
 *
 * -----------------------------------------------------------------------------
 * GEMALTO MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. GEMALTO SHALL NOT BE
 * LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING,
 * MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * THIS SOFTWARE IS NOT DESIGNED OR INTENDED FOR USE OR RESALE AS ON-LINE
 * CONTROL EQUIPMENT IN HAZARDOUS ENVIRONMENTS REQUIRING FAIL-SAFE
 * PERFORMANCE, SUCH AS IN THE OPERATION OF NUCLEAR FACILITIES, AIRCRAFT
 * NAVIGATION OR COMMUNICATION SYSTEMS, AIR TRAFFIC CONTROL, DIRECT LIFE
 * SUPPORT MACHINES, OR WEAPONS SYSTEMS, IN WHICH THE FAILURE OF THE
 * SOFTWARE COULD LEAD DIRECTLY TO DEATH, PERSONAL INJURY, OR SEVERE
 * PHYSICAL OR ENVIRONMENTAL DAMAGE ("HIGH RISK ACTIVITIES"). GEMALTO
 * SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY OF FITNESS FOR
 * HIGH RISK ACTIVITIES.
 *
 * -----------------------------------------------------------------------------
 */

#import <Foundation/Foundation.h>
#import <EzioMobile/EzioMobile.h>

/**
 * Default liveness threshold value
 */
static int DEFAULT_LIVENESS_THRESHOLD = 0;

/**
 * Default quality threshold value
 */
static int DEFAULT_QUALITY_THRESHOLD = 48;

/**
 * Default matching threshold value
 */
static int DEFAULT_MATCHING_THRESHOLD = 50;

/**
 * Default liveness blink timeout value in milliseconds.
 */
static int DEFAULT_LIVENESS_BLINK_TIMEOUT = 4000;

/**
 * Default frame used to enroll.
 */
static int DEFAULT_NUMBER_FRAME_TO_ENROLL = 1;

/**
 * Default frame used to enroll.
 */
static int DEFAULT_COUNT_DOWN_TO_CAPTURE = 5;


/**
 * Default enroller face capture mode.
 */
static EMFaceCaptureMode DEFAULT_VERIFIER_FACE_CAPTURE_MODE = EMFaceCaptureModeLivenessPassive;


/**
 * @discussion Singleton class to handle the save and loading of the facial recognition parameters.
 */
@interface EMFaceSettings : NSObject

/**
 * Get Liveness Threshold
 */
@property (nonatomic) int livenessThreshold;

/**
 * Get Quality Threshold
 */
@property  (nonatomic) int qualityThreshold;

/**
 * Get Matching Threshold
 */
@property  (nonatomic) int matchingThreshold;

/**
 * Get Liveness Blink Timeout in ms
 */
@property  (nonatomic) int livenessBlinkTimeout;

/**
 * Get frame to enroll
 */
@property  (nonatomic) int numberOfFramesToEnroll;


/**
 * Get verifier capture mode
 */
@property (nonatomic) EMFaceCaptureMode verifierFaceCaptureMode;

/**
 * Create the singleton instance of the EMFaceSettings manager
 * Use to load or save the settings of the Face Manager.
 * @return EMFaceSettings
 */
+ (instancetype)sharedInstance;

/**
 * Reset settings to defaults values
 */
- (void) resetDefault;
@end
