*KonyFaceSDK.framework will be dynamically linked with Kony iOS plugin through native bindings.
 EzioMobile.framework is statically linked with KonyFaceSDK.framework.

* Generate Native Bindings:
1. Build KonyFaceSDK.framework. The post build script will copy the framework to output directory of the project folder.
2. Go to src directory of nativebindings folder. nativeframeworks/iOS/nativebinding/src/
2. run below command
python bindgen.py -mn KonyFaceSDK -mv 1.0 -md "KonyFaceSDK" -s  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS10.3.sdk -t 10.3 -i <path to KonyFaceSDK framework>/Headers -tp <path to KonyFaceSDK framework>  KonyFaceID.h -d
3. zip file with name KonyFaceSDK-iOS-10.3.zip will be created in src folder.
4. import this zip in visualizer.(Edit->Manage Native Functions(API)->import).
5. Now API's exposed by KonyFaceSDK.framework will be available in js.
6. IMP: copy the below resources from EzioMobile.framework/Resources to apps resource else the enrolment process will not work.

FacesCreateTemplateMediumLite.ndf
FacesCreateTemplateSmall.ndf
FacesDetectSegmentsFeaturePointsTrack.ndf
FacesDetectSegmentsLiveness.ndf
FacesDetectSegmentsOrientation.ndf
