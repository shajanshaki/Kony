//
//  KonyFaceID.m
//  KonyFaceSDK
//
//  Created by Girish Lingarajappa Haniyamballi on 18/09/17.
//  Copyright © 2017 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import "KonyFaceID.h"
#import <EzioMobile/EzioMobile.h>
#import "FaceSDKUtils.h"
#import "EMFaceManager.h"

@interface KonyFaceID ()
    
    @property( nonatomic,strong) EMFaceAuthService* faceAuthService;
    @property( nonatomic,strong) EMCore *core;
    @property( nonatomic,strong) NSDictionary *config;
    
    @end

@implementation KonyFaceID
    
    
-(BOOL) initializeSDKWithConfig:(NSDictionary*) configuration {
    
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
    self.config = configuration;
    
    if( EMCore.isConfigured == NO) {
        
        EMOtpConfiguration *otpConfig = [EMOtpConfiguration
                                         configurationWithJailbreakPolicy:EMTokenJailbreakPolicyIgnore];
        self.core = [EMCore configureWithConfigurations: [NSSet setWithObjects:otpConfig, nil]];
        
        NSLog(@"%s Succeded", __FUNCTION__);
    }
    
    return YES;
}
    
-(BOOL) isConfigured {
    
    return [[[EMFaceManager sharedInstance] service] isConfigured:nil];
    
}
    
-(BOOL) isInitialized {
    
    return [[[EMFaceManager sharedInstance] service] isInitialized];
    
}
    
    
-(void) initializeWithSuccessCallback:(void (^)()) onSuccess
                       errorCallback :(void (^)(NSError *error))onError {
    
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
    if (self.faceAuthService == nil) {
        //EMAuthModule* authModule = [EMAuthModule authModule];
        self.faceAuthService = [[EMFaceManager sharedInstance] service];
        
        NSError * error = nil;
        
        if ( [self.faceAuthService isSupported:&error]  == NO) {
            NSLog(@"FaceAuth service not supported");
            onError(error);
            return;
        }
    }
    
    if ([self.faceAuthService isLicenseConfigured] ) {
        NSLog(@"License already configured");
        [self initializeFaceAuth:onSuccess errorCallback:onError];
    }else{
        [self.faceAuthService configureLicense:
         ^(EMFaceAuthLicenseBuilder *builder) {
             
             builder.licenseEntitlement = [FaceSDKUtils licenseEntitlementFromConfig:self.config];
             builder.serverUrl = [FaceSDKUtils licenseServerUrlFromConfig:self.config];
         } completion:^(BOOL success, NSError *error) {
             
             if (error) {
                 onError(error);
             }else{
                 [self initializeFaceAuth:onSuccess errorCallback:onError];
             }
         }];
    }
}
    
-(void) enrollWithSuccessCallback:(void (^)()) onSuccess
                   errorCallback :(void (^)(NSError *error))onError {
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
    
    /* 1. Check whether the device is supported */
    if (![[EMFaceManager sharedInstance] isSupported]) {
        
        onError([FaceSDKUtils errorWithMessage:@"Face manager is not supported..."
                                       andCode:FACESDK_DEVICE_NOT_SUPPORTED]);
        return;
    }
    /* 2. Check whether EMFaceManager is still initializing */
    if ([[EMFaceManager sharedInstance] isInitializing]) {
        
        onError([FaceSDKUtils errorWithMessage:@"Face manager is still initializing..."
                                       andCode:FACESDK_INITIALIZING]);
        return;
    }
    /* 3. Check whether Face manager has been initialized. */
    /*    Face Auth APIs cannot be used without the face manager initialized */
    if (![[EMFaceManager sharedInstance] isInitialized]) {
        NSLog(@"Face manager is not initialized. Don't forget to call initialize method");
        
        onError([FaceSDKUtils errorWithMessage:@"Face manager is not initialized. Don't forget to call initialize method"
                                       andCode:FACESDK_NOT_INITIALIZED]);
        return;
    }
    /* 4. Check whether user has been enrolled */
    if ([[[EMFaceManager sharedInstance] service] isConfigured:nil]) {
        NSLog(@"At least one user is already exists. Enroll action rejected.");
        
        onError([FaceSDKUtils errorWithMessage:@"At least one user is already exists."
                                       andCode:FACESDK_USER_ALREADY_REGISTERED]);
        return;
    }
    
    /*
     Present enrollment view with timeout of 60 ms
     Result Code is returned after enrollment, developer must handle accordingly
     */
    
    [self setEnrollerFaceSettings];
    UIViewController* presentingViewController = [FaceSDKUtils topViewController];
    NSInteger enrollTimeout = [FaceSDKUtils enrollTimeoutFromConfig:self.config];
    [EMFaceManager enrollWithPresentingViewController:presentingViewController timeout:enrollTimeout completion:^(EMFaceManagerProcessStatus code) {
        switch (code) {
            case EMFaceManagerProcessStatusFail:; {
                /*
                 Error occured during enrollment
                 Error is stored in faceStatusError object
                 */
                NSString* errorMsg = [NSString stringWithFormat:@"enroll failed with error: %@", [[EMFaceManager sharedInstance] faceStatusError]];
                onError([FaceSDKUtils errorWithMessage:errorMsg andCode:FACESDK_ERROR]);
                break;
            }
            case EMFaceManagerProcessStatusCancel:; {
                /* User cancel the enrollment */
                onError([FaceSDKUtils errorWithMessage:@"User cancel the enrollment" andCode:FACESDK_ERROR]);
                break;
            }
            case EMFaceManagerProcessStatusSuccess:; {
                /* Enrollment is successful */
                NSLog(@"enroll succeed");
                [self createToken:^{
                    onSuccess();
                } errorCallback:^(NSError *error) {
                    onError(error);
                }];
                break;
            }
        }
    }];
    
}
    
-(void) verifyWithSuccessCallback:(void (^)()) onSuccess
                   errorCallback :(void (^)(NSError *error))onError {
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
    
    /* 1. Check whether the device is supported */
    if (![[EMFaceManager sharedInstance] isSupported]) {
        onError([FaceSDKUtils errorWithMessage:@"Face manager is not supported..." andCode:FACESDK_DEVICE_NOT_SUPPORTED] );
        return;
    }
    
    /* 2. Check whether EMFaceManager is still initilaizing */
    if ([[EMFaceManager sharedInstance] isInitializing]) {
        onError([FaceSDKUtils errorWithMessage:@"Face manager is still initializing..." andCode:FACESDK_INITIALIZING] );
        return;
    }
    
    /* 3. Check whether Face manager has been initialized */
    if (![[EMFaceManager sharedInstance] isInitialized]) {
        onError([FaceSDKUtils errorWithMessage:@"Face manager is not initialized. Don't forget to call initialize method" andCode:FACESDK_NOT_INITIALIZED] );
        return;
    }
    
    /* 4. Check whether user has been enrolled */
    if (![[[EMFaceManager sharedInstance] service] isConfigured:nil]) {
        onError([FaceSDKUtils errorWithMessage:@"Place do enroll before calling verify..." andCode:FACESDK_USER_NOT_ENROLLED] );
        return;
    }
    
    
    BOOL isSuccess = NO;
    id token = [self getToken:&isSuccess withErrorhandler:onError];
    if ( isSuccess == NO ) {
        return;
    }
    
    /*
     Verify user for selected token
     */
    
    [self setVerifierFaceSettings];
    NSInteger verifyTimeout = [FaceSDKUtils enrollTimeoutFromConfig:self.config];
    [EMFaceManager verifyWithPresentingViewController:(UIViewController*) [FaceSDKUtils topViewController]
                                      authenticatable:token
                                              timeout:verifyTimeout
                                           completion:^(EMFaceManagerProcessStatus code,id<EMFaceAuthInput> authInput){
                                               switch (code) {
                                                   case EMFaceManagerProcessStatusFail:; {
                                                       /*
                                                        Error occured during verification
                                                        Error is stored in faceStatusError object
                                                        */
                                                       onError([FaceSDKUtils errorWithMessage:[[EMFaceManager sharedInstance] faceStatusError] andCode:FACESDK_ERROR]);
                                                       break;
                                                   }
                                                   case EMFaceManagerProcessStatusCancel:; {
                                                       /* User canceled during verification */
                                                       onError([FaceSDKUtils errorWithMessage:@"verify canceled" andCode:FACESDK_ERROR]);
                                                       break;
                                                   }
                                                   case EMFaceManagerProcessStatusSuccess:; {
                                                       //NSLog(@"Verification success");
                                                       onSuccess();
                                                       break;
                                                   }
                                               }
                                               
                                           }];
    
}
    
-(void) unEnrollWithSuccessCallback:(void (^)()) onSuccess
                     errorCallback :(void (^)(NSError *error))onError {
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
    if(self.faceAuthService == nil) {
        onError([FaceSDKUtils errorWithMessage:@"Auth Service not created" andCode:FACESDK_NOT_INITIALIZED]);
        return;
    }
    
    if(![self.faceAuthService isInitialized]) {
        NSLog(@"FaceAuth service not initialized.");
        onError([FaceSDKUtils errorWithMessage:@"FaceAuth service not initialized." andCode:FACESDK_NOT_INITIALIZED]);
        return;
    }
    
    NSError* error = nil;
    if([self.faceAuthService isConfigured:&error] == NO) {
        NSLog(@"Face not enrolled");
        onError(error);
        return;
    }
    
    EMFaceAuthFactory* faceAuthFactory = [self.faceAuthService faceAuthFactory];
    
    EMFaceAuthEnrollerSettings*  enrollerSettings = [faceAuthFactory createFaceAuthEnrollerSettings];
    [enrollerSettings setQualityThreshold:[[EMFaceSettings sharedInstance] qualityThreshold]];
    [enrollerSettings setLivenessThreshold:[[EMFaceSettings sharedInstance] livenessThreshold]];
    [enrollerSettings setNumberOfFramesToEnroll:[[EMFaceSettings sharedInstance] numberOfFramesToEnroll]];
    [enrollerSettings setCountdownToCapture:0];
    id<EMFaceAuthEnroller> enroller = [faceAuthFactory createFaceAuthEnrollerWithSettings:enrollerSettings];
    [enroller unenrollWithCompletion:^(BOOL success, NSError *error) {
        if (success) {
            onSuccess();
        }else if(error) {
            NSLog(@"Face unenroll failed with error %@", error.description);
            onError(error);
        }else{
            NSLog(@"FAce unenroll failed with unknown error");
            onError([FaceSDKUtils errorWithMessage:@"FAce unenroll failed with unknown error" andCode:FACESDK_ERROR]);
        }
        
    }];
    
}
    
-(void) cancelEnrollment {
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
}
    
-(void) cancelVerification {
    NSLog(@"%s", __PRETTY_FUNCTION__);
    
    
}
    
-(void) uninitialize {
    NSLog(@"%s", __PRETTY_FUNCTION__);
    [self.faceAuthService uninitializeWithCompletion:^(BOOL success, NSError *error) {
        NSLog(@"Face Auth Service uninitialized");
    }];
}
    
    
    // Helper methods
-(void) initializeFaceAuth:(void (^)()) onSuccess
            errorCallback :(void (^)(NSError *error))onError  {
    
    NSError* error = nil;
    BOOL faceIdSupported = [self.faceAuthService isSupported:&error];
    BOOL faceIdInitialized = [self.faceAuthService isInitialized];
    // Init face id service
    if (faceIdSupported && !faceIdInitialized) {
        [self.faceAuthService initializeWithCompletion:
         ^(BOOL isInitialized, NSError *error) {
             if (error) {
                 onError(error);
             }else{
                 // Check isInitialized status
                 if(isInitialized) {
                     onSuccess();
                 }
             }
         }];
    }else{
        onSuccess();
    }
}
    
-(void) createToken:(void (^)()) onSuccess
     errorCallback :(void (^)(NSError *error))onError {
    
    GemaltoTokenType tokenType =  [FaceSDKUtils tokenTypeFromConfig:self.config];
    
    if(tokenType == GemaltoTokenTypeOATH){
        [self createOATHToken:onSuccess errorCallback:onError];
    }else if(tokenType == GemaltoTokenTypeCAP){
        [self createCAPToken:onSuccess errorCallback:onError];
    }
}
    
-(id) getToken: (BOOL*) isSuccess withErrorhandler: (void (^)(NSError *error))onError{
    
    id token = nil;
    *isSuccess = YES;
    GemaltoTokenType tokenType =  [FaceSDKUtils tokenTypeFromConfig:self.config];
    
    if(tokenType == GemaltoTokenTypeOATH){
        token = [self getOATHToken:isSuccess withErrorhandler:onError];
    }else if(tokenType == GemaltoTokenTypeCAP){
        token = [self getCAPToken:isSuccess withErrorhandler:onError];
    }
    return token;
}
    
-(id) getOATHToken:(BOOL*) isSuccess withErrorhandler: (void (^)(NSError *error))onError{
    
    id oathToken = nil;
    
    EMOtpModule *otpModule = [EMOtpModule otpModule];
    // create OATH service
    EMOathService *oathService = [EMOathService serviceWithModule:otpModule];
    
    // Retrieve the token manager
    NSError* error = nil;
    id<EMOathTokenManager> tokenManager = [oathService tokenManager:&error];
        if (error) {
            *isSuccess = NO;
            onError(error);
        }
    @try {
        oathToken = [tokenManager tokenWithName:[FaceSDKUtils tokenNameFromConfig:self.config]
                                          error:&error];
        if (error) {
            *isSuccess = NO;
            onError(error);
        }

    } @catch (NSException *exception) {
        
    }
    return oathToken;
    
}
    
-(id) getCAPToken:(BOOL*) isSuccess withErrorhandler: (void (^)(NSError *error))onError {
    EMOtpModule *otpModule = [EMOtpModule otpModule];
    // create CAP service
    EMCapService *capService = [EMCapService serviceWithModule:otpModule];
    
    // Retrieve the token manager
    NSError* error = nil;
    id<EMCapTokenManager> tokenManager = [capService tokenManager:&error];
    if (error) {
        *isSuccess = NO;
        onError(error);
    }

    id token = nil;
    
    @try {
        token = [tokenManager tokenWithName:[FaceSDKUtils tokenNameFromConfig:self.config] error:&error];
        if (error) {
            *isSuccess = NO;
            onError(error);
        }
    } @catch (NSException *exception) {
        
    }
    
    return token;
}
    

-(void) createCAPToken:(void (^)()) onSuccess
        errorCallback :(void (^)(NSError *error))onError {
    BOOL isSuccess;
    __block id token = [self getCAPToken:&isSuccess withErrorhandler:onError];
    if (token == nil) {
        EMOtpModule *otpModule = [EMOtpModule otpModule];
        // create CAP service
        EMCapService *capService = [EMCapService serviceWithModule:otpModule];
        
        // Retrieve the token manager
        NSError* error = nil;
        id<EMCapTokenManager> tokenManager = [capService tokenManager:&error];

        [tokenManager createTokenWithName:[FaceSDKUtils tokenNameFromConfig:self.config] provisioningConfiguration:[self getOfflineTokenConfiguration] completionHandler:^(id<EMCapToken> emcapToken, NSError * error) {
            token = emcapToken;
            [self checkAndUpgrateToken:token successCallback:onSuccess errorCallback:onError];
        }];
    }else{
        [self checkAndUpgrateToken:token successCallback:onSuccess errorCallback:onError];
    }
}
    
-(void) createOATHToken:(void (^)()) onSuccess
         errorCallback :(void (^)(NSError *error))onError {
    
    BOOL isSuccess;
    __block id token = [self getOATHToken:&isSuccess withErrorhandler:onError];
    
    if (token == nil) {
        EMOtpModule *otpModule = [EMOtpModule otpModule];
        // create OATH service
        EMOathService *oathService = [EMOathService serviceWithModule:otpModule];
        
        // Retrieve the token manager
        NSError* error = nil;
        id<EMOathTokenManager> tokenManager = [oathService tokenManager:&error];

        GemaltoTokenConfigType tokenConfgType = [FaceSDKUtils tokenConfigTypeFromConfig:self.config];
        [tokenManager createTokenWithName:[FaceSDKUtils tokenNameFromConfig:self.config] provisioningConfiguration:[self getProvisioningConfigurationForTokenConfigType:tokenConfgType] completionHandler:^(id<EMOathToken> emOATHToken, NSError* error) {
            if (error) {
                onError(error);
            }else{
                token = emOATHToken;
                [self checkAndUpgrateToken:token successCallback:onSuccess errorCallback:onError];
            }
        }];
    }else{
        
        [self checkAndUpgrateToken:token successCallback:onSuccess errorCallback:onError];
        
    }
    
}

-(EMProvisioningConfiguration*) getProvisioningConfigurationForTokenConfigType:(GemaltoTokenConfigType) tokenConfigType {
    EMProvisioningConfiguration* provConfig = nil;
    
    switch (tokenConfigType) {
        case CLEAR_TEXT:
        provConfig = [self getClearTextSecretTokenConfiguration];
        break;
        
        case EPS:
        provConfig = [self getEpsTokenConfiguration];
        break;
        
        case OFFLINE:
        default:
        provConfig = [self getOfflineTokenConfiguration];
        break;
    }
    return provConfig;
}
    
-(void) checkAndUpgrateToken :(id) token successCallback:(void (^)()) onSuccess
               errorCallback :(void (^)(NSError *error))onError{
    
    NSError* error = nil;
    // Create an object that represents pin authentication service.
    EMAuthModule* authModule = [EMAuthModule authModule];
    EMPinAuthService* pinAuthService = [EMPinAuthService serviceWithModule:authModule];
    // Create an PinAuthInput object that represents pin authentication.
    // sPin should be the String PIN input obtained from the user.
    NSData* sData = [[FaceSDKUtils pinFromConfig:self.config] dataUsingEncoding:NSUTF8StringEncoding];
    id<EMPinAuthInput> pinAuthInput = [pinAuthService createAuthInputWithData:sData error:&error];
    if (error) {
        onError(error);
        return;
    }
    
    // Use the pinAuthInput to verify an OTP before continue here.
    // In order to activate fingerprint mode, we need to first upgrade the token to
    // support multi auth mode.
    // Pass object that represents pin authentication functionality as parameter
    // Upgrade token object.
    
    if (![token isMultiAuthModeEnabled]) {
        BOOL result = [token upgradeToMultiAuthMode:pinAuthInput error:&error];
        if (!result) {
            onError(error);
            return;
        }
    }
    
    [token activateAuthMode:[self getFaceAuthService].authMode usingActivatedInput:pinAuthInput error:&error];
    if (error) {
        onError(error);

    }else{
        NSLog(@"Auth mode activated");
        onSuccess();
    }
    // Wipe the pin
    [pinAuthInput wipe];
    
}

-(EMFaceAuthService*) getFaceAuthService {
    EMAuthModule* authModule = [EMAuthModule authModule];
    return [EMFaceAuthService serviceWithModule:authModule];
    
}
    
-(EMProvisioningConfiguration*) getEpsTokenConfiguration{
    //TODO
    return nil;
}
-(EMProvisioningConfiguration*) getClearTextSecretTokenConfiguration {
    
    
    NSError* error = nil;
    EMAuthModule* authModule = [EMAuthModule authModule];
    EMPinAuthService* pinAuthService = [EMPinAuthService serviceWithModule:authModule];
    
    NSData* userPin = [[FaceSDKUtils pinFromConfig:self.config] dataUsingEncoding:NSUTF8StringEncoding];
    id<EMPinAuthInput> pinAuthInput = [pinAuthService createAuthInputWithData:userPin error:&error];
    if (error) {
        // Handle error
    }
    
    id<EMSecureByteArray> secret = [self getSecret];
    
    EMProvisioningConfiguration *clearTextConfig = [EMProvisioningConfiguration clearTextSeedImportConfigurationWithPin:pinAuthInput secret:secret optionalParameters:^(EMClearTextSecretTokenConfigurationBuilder *builder) {
        //builder.userTokenId = userTokenId; TODO: whats the value for userTokenID
    }];
    return clearTextConfig;
}
    
-(id<EMSecureByteArray>) getSecret {
        NSData* secret = nil;
        NSString* secretString = [FaceSDKUtils tokenConfigSecretFromConfig:self.config];
        
        if ( secretString ) {
            secret = [FaceSDKUtils dataFromHexString:secretString];
        }
        id<EMSecureContainerFactory> scf = [[EMCore sharedInstance] secureContainerFactory];
        return [scf secureStringFromData:secret
                       wipeSource:YES];
        
    }

    
-(EMProvisioningConfiguration*) getOfflineTokenConfiguration {
    
    NSData* sessionKey = [self getSessionKey];
    
    id<EMSecureContainerFactory> scf = [[EMCore sharedInstance] secureContainerFactory];
    // The second argg wipes the rawPassword data
    id<EMSecureString> secSessionKey = [scf secureStringFromData:sessionKey
                                                      wipeSource:YES];
    
    
    NSData* provisioningResponse = [self getProvisioningResponse];
    id<EMSecureString> secProvisioningResponse = [scf secureStringFromData:provisioningResponse
                                                                wipeSource:YES];
    
    
    EMMobileProvisioningProtocol protocolVersion = [FaceSDKUtils protocolVersionFromConfig:self.config];
    EMProvisioningConfiguration *offlineTokenConfig = [EMProvisioningConfiguration offlineTokenConfigurationWithSessionKey:secSessionKey provisioningResponse:secProvisioningResponse provisioningProtocol:protocolVersion];
    
    return offlineTokenConfig;
}

    
    
- (NSString *) stringToHex:(NSString *)str
    {
        NSUInteger len = [str length];
        unichar *chars = malloc(len * sizeof(unichar));
        [str getCharacters:chars];
        
        NSMutableString *hexString = [[NSMutableString alloc] init];
        
        for(NSUInteger i = 0; i < len; i++ )
        {
            [hexString appendString:[NSString stringWithFormat:@"%x", chars[i]]];
        }
        free(chars);
        
        return hexString;
    }
    
    //5A AC F3 AC E4 DF DB E6 AA 2E F9 BE C8 C2 E5 AC D1 A2 A6 AA 3F 77 E2 B2
    //    unsigned char bytes[] = {0x5A, 0xAC, 0xF3, 0xAC, 0xE4, 0xDF, 0xDB, 0xE6, 0xAA, 0x2E, 0xF9, 0xBE, 0xC8, 0xC2, 0xE5, 0xAC, 0xD1, 0xA2, 0xA6, 0xAA, 0x3F, 0x77, 0xE2, 0xB2};
    //
    //    NSData* sessionKey = [NSData dataWithBytes:bytes length:sizeof(bytes)];
    
    //    NSString *str = [@"" cStringUsingEncoding:NSUTF8StringEncoding];
    
-(NSData*) getSessionKey
    {
        NSData* sessionKey = nil;
        NSString* sessionKeyString = [FaceSDKUtils sessionKeyFromConfig:self.config];
        
        if ( sessionKeyString ) {
            sessionKey = [FaceSDKUtils dataFromHexString:sessionKeyString];
        }
        
        return sessionKey;
        
    }
    
    
    //C0 09 A3 BC BF DE 0E 8A 0B 5F CB 53 62 88 0E 71 6B 68 29 25 1C 4D 45 FA
    //    unsigned char bytes[] = {0xC0, 0x09, 0xA3, 0xBC, 0xBF, 0xDE, 0x0E, 0x8A, 0x0B, 0x5F, 0xCB, 0x53, 0x62, 0x88, 0x0E, 0x71, 0x6B, 0x68, 0x29, 0x25, 0x1C, 0x4D, 0x45, 0xFA};
    //    NSData* provisioningResponse = [NSData dataWithBytes:bytes length:sizeof(bytes)];
    //    return provisioningResponse;
    
-(NSData*) getProvisioningResponse {
    
    NSData* provisioningResponse = nil;
    NSString* provisioningResponseString = [FaceSDKUtils provisioningResponseFromConfig:self.config];
    
    if (provisioningResponseString) {
        provisioningResponse = [FaceSDKUtils dataFromHexString:provisioningResponseString];
    }
    return provisioningResponse;
}
    
-(void) setVerifierFaceSettings {
    
    [self setFaceSettingsForConfig:KONY_FACE_SDK_VERIFY_CONFIG];
}
    
-(void) setEnrollerFaceSettings {
    
    [self setFaceSettingsForConfig:KONY_FACE_SDK_ENROLL_CONFIG];
    
}
    
-(void) setFaceSettingsForConfig:(NSString*) configName {
    
    NSInteger blinkTimeout = [FaceSDKUtils valueForKey:KONY_FACE_SDK_BLINK_TIMEOUT_KEY inSection:configName fromConfig:self.config];
    if (blinkTimeout != -1) {
        [[EMFaceSettings sharedInstance] setLivenessBlinkTimeout:(int)blinkTimeout];
    }
    
    NSInteger livenessThreshold = [FaceSDKUtils valueForKey:KONY_FACE_SDK_LIVENESS_THRESHOLD inSection:configName fromConfig:self.config];
    if (livenessThreshold != -1) {
        [[EMFaceSettings sharedInstance] setLivenessThreshold:(int)livenessThreshold];
    }
    
    NSInteger qualityThreshold = [FaceSDKUtils valueForKey:KONY_FACE_SDK_QUALITY_THRESHOLD inSection:configName fromConfig:self.config];
    if (qualityThreshold != -1) {
        [[EMFaceSettings sharedInstance] setQualityThreshold:(int)qualityThreshold];
    }
    
    NSInteger matchingThreshold = [FaceSDKUtils valueForKey:KONY_FACE_SDK_MATCHING_THRESHOLD inSection:configName fromConfig:self.config];
    if (qualityThreshold != -1) {
        [[EMFaceSettings sharedInstance] setMatchingThreshold:(int)matchingThreshold];
    }
    
}
    
    
    @end
