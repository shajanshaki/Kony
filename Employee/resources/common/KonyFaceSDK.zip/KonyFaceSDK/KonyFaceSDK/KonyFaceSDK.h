//
//  KonyFaceSDK.h
//  KonyFaceSDK
//
//  Created by Girish Lingarajappa Haniyamballi on 18/09/17.
//  Copyright © 2017 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KonyFaceSDK.
FOUNDATION_EXPORT double KonyFaceSDKVersionNumber;

//! Project version string for KonyFaceSDK.
FOUNDATION_EXPORT const unsigned char KonyFaceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KonyFaceSDK/PublicHeader.h>
#import <KonyFaceSDK/KonyFaceID.h>

