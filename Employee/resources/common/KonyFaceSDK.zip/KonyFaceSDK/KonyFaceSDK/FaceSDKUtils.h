//
//  FaceSDKUtils.h
//  KonyFaceSDK
//
//  Created by Girish Lingarajappa Haniyamballi on 19/09/17.
//  Copyright © 2017 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FaceSDKConstants.h"
#import <EzioMobile/EMProvisioningConfiguration.h>

@interface FaceSDKUtils : NSObject

    + (NSString*) licenseEntitlementFromConfig:(NSDictionary*) config;
    + (NSString*) licenseServerUrlFromConfig:(NSDictionary*) config;
    + (NSString*) sessionKeyFromConfig:(NSDictionary*) config;
    + (NSString*) provisioningResponseFromConfig:(NSDictionary*) config;
    + (NSString*) tokenNameFromConfig:(NSDictionary*) config;
    + (GemaltoTokenConfigType) tokenConfigTypeFromConfig:(NSDictionary*) config;
    + (GemaltoTokenType) tokenTypeFromConfig:(NSDictionary*) config;
    + (NSString*) pinFromConfig:(NSDictionary*) config;
    + (EMMobileProvisioningProtocol) protocolVersionFromConfig:(NSDictionary*) config;
    + (NSInteger) verifyTimeoutFromConfig:(NSDictionary*) config;
    + (NSInteger) enrollTimeoutFromConfig:(NSDictionary*) config;
    + (NSInteger) valueForKey:(NSString*) key
                    inSection:(NSString*) section
                   fromConfig:(NSDictionary*) config;
    +(NSString*) stringValueForKey:(NSString*)key
                         inSection:(NSString*) sectionName
                          inConfig:(NSDictionary*) config;
    +(UIViewController *)topViewController;
    +(NSError*) errorWithMessage:(NSString*) message andCode:(NSInteger) code;
    +(NSData *) dataFromHexString:(NSString*) str;
    +(NSString*) tokenConfigSecretFromConfig:(NSDictionary*) config;
@end
