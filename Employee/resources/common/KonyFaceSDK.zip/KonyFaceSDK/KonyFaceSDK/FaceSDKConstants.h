//
//  FaceSDKConstants.h
//  KonyFaceSDK
//
//  Created by Girish Lingarajappa Haniyamballi on 22/09/17.
//  Copyright © 2017 Girish Lingarajappa Haniyamballi. All rights reserved.
//

#ifndef FaceSDKConstants_h
#define FaceSDKConstants_h


typedef NS_ENUM(NSInteger, GemaltoLivenessMode) {
    Image = 0, /** Mode used in enrollment or verification which indicates face should be still. */
    LivenessPassive = 1 /** Mode used in enrollment or verification indicating captured face is alive. */
};


//Type of token
typedef NS_ENUM(NSInteger, GemaltoTokenType) {
    GemaltoTokenTypeOATH = 0,
    GemaltoTokenTypeCAP = 1
};



//Type of token configuration
typedef NS_ENUM(NSInteger, GemaltoTokenConfigType) {
    EPS = 0,
    CLEAR_TEXT = 1,
    OFFLINE = 2
};


//Type of token configuration
typedef NS_ENUM(NSInteger, GemaltoProvisioningProtolVersion) {
    V1 = 1,
    V2 = 2,
    V3 = 3
};

#define KONY_FACE_SDK_LICENCE_CONFIG_KEY @"licenseConfig"
#define KONY_FACE_SDK_LICENCE_KEY @"licenseString"
#define KONY_FACE_SDK_LICENCE_SERVER_URL @"licenseServerUrl"
#define KONY_FACE_SDK_TOKEN_CONFIG_KEY @"tokenConfig"
#define KONY_FACE_SDK_TOKEN_CONFIG_TYPE_KEY @"tokenConfigType"
#define KONY_FACE_SDK_TOKEN_TYPE_KEY @"tokenType"
#define KONY_FACE_SDK_SESSIONKEY_KEY @"sessionKey"
#define KONY_FACE_SDK_TOKEN_NAME_KEY @"tokenName"
#define KONY_FACE_SDK_PROVISIONING_RESPONSE_KEY @"provisioningResponse"
#define KONY_FACE_SDK_PIN @"pin"
#define KONY_FACE_SDK_ENROLL_CONFIG @"enrollConfig"
#define KONY_FACE_SDK_VERIFY_CONFIG @"verifyConfig"
#define KONY_FACE_SDK_TIMEOUT_KEY @"timeout"
#define KONY_FACE_SDK_BLINK_TIMEOUT_KEY @"blinkTimeout" 
#define KONY_FACE_SDK_LIVENESS_MODE @"livenessMode"
#define KONY_FACE_SDK_LIVENESS_THRESHOLD @"livenessThreshold"
#define KONY_FACE_SDK_QUALITY_THRESHOLD @"qualityThreshold"
#define KONY_FACE_SDK_MATCHING_THRESHOLD @"matchingThreshold"
#define KONY_FACE_SDK_SECRET_KEY @"secret"
#define KONY_FACE_SDK_PROTOCOL_VERSION_KEY @"protocolVersion"

#endif /* FaceSDKConstants_h */
