//
//  FaceSDKUtils.m
//  KonyFaceSDK
//
//  Created by Girish Lingarajappa Haniyamballi on 19/09/17.
//  Copyright © 2017 Girish Lingarajappa Haniyamballi. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "FaceSDKUtils.h"

@implementation FaceSDKUtils
    
+ (NSString*) licenseEntitlementFromConfig:(NSDictionary*) config {
    
    return  [self stringValueForKey:KONY_FACE_SDK_LICENCE_KEY inSection:KONY_FACE_SDK_LICENCE_CONFIG_KEY inConfig:config];
    
}
+ (NSString*) licenseServerUrlFromConfig:(NSDictionary*) config {
    
    return  [self stringValueForKey:KONY_FACE_SDK_LICENCE_SERVER_URL inSection:KONY_FACE_SDK_LICENCE_CONFIG_KEY inConfig:config];
    
}
    
+ (NSString*) sessionKeyFromConfig:(NSDictionary*) config {
    
    return  [self stringValueForKey:KONY_FACE_SDK_SESSIONKEY_KEY inSection:KONY_FACE_SDK_TOKEN_CONFIG_KEY inConfig:config];
}
    
+ (NSString*) provisioningResponseFromConfig:(NSDictionary*) config {
    
    return  [self stringValueForKey:KONY_FACE_SDK_PROVISIONING_RESPONSE_KEY inSection:KONY_FACE_SDK_TOKEN_CONFIG_KEY inConfig:config];
}
    
+ (NSString*) pinFromConfig:(NSDictionary*) config {
    
    NSString* pin = nil;
    
    if (config && [config isKindOfClass:[NSDictionary class] ]){
        NSDictionary* tokenConfigDictionary = config[KONY_FACE_SDK_TOKEN_CONFIG_KEY];
        if (tokenConfigDictionary) {
            id pinValue = tokenConfigDictionary[KONY_FACE_SDK_PIN];
            if (pinValue && [pinValue isKindOfClass:[NSNumber class]]) {
                pin = [(NSNumber*)pinValue stringValue];
            }else if (pinValue && [pinValue isKindOfClass:[NSString class]]) {
                pin = pinValue;
            }
        }
    }
    
    if (pin == nil) {
        NSLog(@"pin not found in config");
    }
    return pin;
}
    
+ (NSString*) tokenNameFromConfig:(NSDictionary*) config {
    
    return [self stringValueForKey:KONY_FACE_SDK_TOKEN_NAME_KEY inSection:KONY_FACE_SDK_TOKEN_CONFIG_KEY inConfig:config];
}
    
+ (GemaltoTokenType) tokenTypeFromConfig:(NSDictionary*) config {
    
    GemaltoTokenType tokenType = GemaltoTokenTypeCAP;
    
    if (config && [config isKindOfClass:[NSDictionary class] ]){
        NSDictionary* tokenConfigDictionary = config[KONY_FACE_SDK_TOKEN_CONFIG_KEY];
        if (tokenConfigDictionary) {
            id tempTokenType = tokenConfigDictionary[KONY_FACE_SDK_TOKEN_TYPE_KEY];
            if (tempTokenType) {
                tokenType = (GemaltoTokenType)[tempTokenType integerValue];
            }
        }
    }
    return tokenType;
}
    
+ (GemaltoTokenConfigType) tokenConfigTypeFromConfig:(NSDictionary*) config {
    
    GemaltoTokenConfigType tokenConfigType = OFFLINE;
    
    if (config && [config isKindOfClass:[NSDictionary class] ]){
        NSDictionary* tokenConfigDictionary = config[KONY_FACE_SDK_TOKEN_CONFIG_KEY];
        if (tokenConfigDictionary) {
            id tempTokenConfigType = tokenConfigDictionary[KONY_FACE_SDK_TOKEN_CONFIG_TYPE_KEY];
            if (tempTokenConfigType) {
                tokenConfigType = (GemaltoTokenConfigType)[tempTokenConfigType integerValue];
            }
        }
    }
    return tokenConfigType;
}
    
+ (EMMobileProvisioningProtocol) protocolVersionFromConfig:(NSDictionary*) config {
    
    EMMobileProvisioningProtocol protocol = EMMobileProvisioningProtocolVersion2;
    
    GemaltoProvisioningProtolVersion retVal = [self valueForKey:KONY_FACE_SDK_PROTOCOL_VERSION_KEY inSection:KONY_FACE_SDK_TOKEN_CONFIG_KEY fromConfig:config];
    
    switch (retVal) {
        case V1:
        protocol = EMMobileProvisioningProtocolVersion1;
        break;
        case V2:
        protocol = EMMobileProvisioningProtocolVersion2;
        break;
        case V3:
        protocol = EMMobileProvisioningProtocolVersion3;
        break;
    }
    return protocol;
}
    
+ (NSInteger) enrollTimeoutFromConfig:(NSDictionary*) config {
    
    return [self valueForKey:KONY_FACE_SDK_TIMEOUT_KEY inSection:KONY_FACE_SDK_ENROLL_CONFIG fromConfig:config];
    
}
    
+ (NSInteger) verifyTimeoutFromConfig:(NSDictionary*) config {
    
    return [self valueForKey:KONY_FACE_SDK_TIMEOUT_KEY inSection:KONY_FACE_SDK_VERIFY_CONFIG fromConfig:config];
    
}
    
+ (NSInteger) livenessBlinkTimeoutFromConfig:(NSDictionary*) config {
    
    return [self valueForKey:KONY_FACE_SDK_BLINK_TIMEOUT_KEY inSection:KONY_FACE_SDK_VERIFY_CONFIG fromConfig:config];
}
    
+ (NSInteger) livenessThresholdFromConfig:(NSDictionary*) config {
    
    return [self valueForKey:KONY_FACE_SDK_LIVENESS_THRESHOLD inSection:KONY_FACE_SDK_VERIFY_CONFIG fromConfig:config];
    
}
    
+ (NSInteger) qualityThresholdFromConfig:(NSDictionary*) config {
    
    return [self valueForKey:KONY_FACE_SDK_QUALITY_THRESHOLD inSection:KONY_FACE_SDK_VERIFY_CONFIG fromConfig:config];
    
}
    
+ (NSInteger) matchingThresholdFromConfig:(NSDictionary*) config {
    
    return [self valueForKey:KONY_FACE_SDK_MATCHING_THRESHOLD inSection:KONY_FACE_SDK_VERIFY_CONFIG fromConfig:config];
}
    
+(NSString*) tokenConfigSecretFromConfig:(NSDictionary*) config {
    
    return [self stringValueForKey:KONY_FACE_SDK_SECRET_KEY inSection:KONY_FACE_SDK_TOKEN_CONFIG_KEY inConfig:config];
    
}
    
+(NSString*) stringValueForKey:(NSString*)key
                     inSection:(NSString*) sectionName
                      inConfig:(NSDictionary*) config {
    
    NSString* retVal = nil;
    
    if (config && [config isKindOfClass:[NSDictionary class] ]){
        NSDictionary* tokenConfigDictionary = config[sectionName];
        if (tokenConfigDictionary) {
            NSString* tempVal = tokenConfigDictionary[key];
            if (tempVal) {
                retVal = tempVal;
            }
        }
    }
    
    if (retVal == nil) {
        NSLog(@"key not found in config");
    }
    return retVal;
    
}
    
+ (NSInteger) valueForKey:(NSString*) key inSection:(NSString*)  section fromConfig:(NSDictionary*) config {
    
    NSInteger retVal = -1;
    
    if (key == nil || ![key isKindOfClass: [NSString class]] || key.length == 0 ||
        section == nil || ![section isKindOfClass: [NSString class]] || section.length == 0 ) {
        return -1;
    }
    
    if (config && [config isKindOfClass:[NSDictionary class] ]){
        NSDictionary* sectionConfigDictionary = config[section];
        if (sectionConfigDictionary) {
            id tempValue = sectionConfigDictionary[key];
            if (tempValue && tempValue != (id)[NSNull null] ) {
                retVal = [tempValue integerValue];
            }
        }
    }
    return retVal;
}
    
+ (UIViewController *)topViewController{
    return [self topViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
}
    
+ (UIViewController *)topViewController:(UIViewController *)rootViewController
    {
        if (rootViewController.presentedViewController == nil) {
            return rootViewController;
        }
        
        if ([rootViewController.presentedViewController isKindOfClass:[UINavigationController class]]) {
            UINavigationController *navigationController = (UINavigationController *)rootViewController.presentedViewController;
            UIViewController *lastViewController = [[navigationController viewControllers] lastObject];
            return [self topViewController:lastViewController];
        }
        
        UIViewController *presentedViewController = (UIViewController *)rootViewController.presentedViewController;
        return [self topViewController:presentedViewController];
    }
    
+(NSError*) errorWithMessage:(NSString*) message andCode:(NSInteger) code {
    return [NSError errorWithDomain:@"KonyFaceID" code:code
                           userInfo:@{ NSLocalizedDescriptionKey: NSLocalizedString(message, nil)}];
}
    
+ (NSData *)dataFromHexString:(NSString*) str {
    
    NSMutableString* stringToConvert = [NSMutableString stringWithString:str];
    
    if (str.length % 2 != 0) {
        [stringToConvert insertString:@"0" atIndex:0];
    }
    const char *chars = [stringToConvert UTF8String];
    int i = 0, len = (int)stringToConvert.length;
    
    NSMutableData *data = [NSMutableData dataWithCapacity:len / 2];
    char byteChars[3] = {'\0','\0','\0'};
    unsigned long wholeByte;
    
    while (i < len) {
        byteChars[0] = chars[i++];
        byteChars[1] = chars[i++];
        wholeByte = strtoul(byteChars, NULL, 16);
        [data appendBytes:&wholeByte length:1];
    }
    
    return data;
}
    
    @end
