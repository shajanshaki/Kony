Overview
This readme file contains the information and instructions needed to
install and use the finalizer, the utility that completes the
protection of a static library provided by your vendor. The
finalizer utility is executed on the binary file output by the linker.
The utility completes the protection process for the static library
code that is linked into the binary file.

You can use the finalizer utility provided in this package to
finalize protections for the code linked in from libraries for
the following target platforms:
   o  Android ARM
   o  Android x86
   o  Apple iOS

_____________________________________________________________
Contents of the Finalizer Package
When the contents are extracted, the following folders and contents
are on disk:

Finalizer-<version_number>-macosx-x64, a folder containing:
     o   finalizer
     o   setenv.sh
     o   readme.txt
     o   Xcode, a folder containing the following:
         o xcode-finalize-protection.py
         o deprecated, a folder that contains the deprecated wrapper
           script and the script to install that wrapper script

_____________________________________________________________
Installation Requirements
The host on which you run the finalizer must satisfy the following
requirements:

For Android targets:
        OS: Mac OS X
       CPU: x64-compatible

For Apple iOS targets:
        OS: Mac OS X
       CPU: x64-compatible
  Compiler: Clang
  Software: Xcode
            

_____________________________________________________________
Installing the Finalizer Package
1. Make sure the host meets the requirements described above in
   Installation Requirements.
2. Extract the contents of the Finalizer package to a directory of
   your choice on the host.

_____________________________________________________________
Setting Environment Variables
Before you run the finalizer, source the setenv.sh script to set
needed environment variables:
    source <finalizer_kit_path>/setenv.sh

iOS Note: Environment variables are set automatically by the
invoked script when you use the finalizer.


_____________________________________________________________
Completing the Protection
This section describes how to use this kit to complete the
protection and produce a binary file with the linked,
protected library. This section has separate instructions
for each target platform and a description of the finalizer utility's
command line.

_ _ _ _ _ _ _ _ _ _ _
For Android Targets
After receiving a partially protected static library (.a) and .fin
file(s) from your vendor, do the following:
  1. Create the application's binary file, using your system's
     linker. You must generate a map file.
     
     To generate a map file, add the following to the
       Android.mk file:
         LOCAL_LDFLAGS+=-Wl,-Map,<program_name>.map

  2. Run the output binary file through the finalizer. You must 
     use the unstripped binary output. The ndk-build process stores 
     the unstripped version of the binary in:
     <project>/obj/local/<abi>
     (See note #2 in IMPORTANT NOTES for more details.) 

     The finalizer command line is:
          finalizer [options] -strip-cmd <path_to_strip_command>
        <unstripped_binary_file_name> <map_file_name> <fin_file_name>
        -o <output_binary_name>

     See the description of the Finalizer Command Line Arguments below.
  
  3. Copy the output of the finalizer to the <project>/libs/<abi>/ 
     directory. 

IMPORTANT NOTES:
1. The value for <path_to_strip_command> should be an appropriate
   cross-tool strip utility such as:

<NDK_ROOT>/toolchains/arm-linux-androideabi-4.9/prebuilt/darwin-x86_64/bin/arm-linux-androideabi-strip

2. Be careful to finalize the correct version of
   the shared library. The ndk-build process creates two output 
   binaries: one is unstripped (still contains symbols) and one is 
   stripped (symbols are removed). The finalizer requires the 
   unstripped version to complete the protection. 

   The ndk-build process places the unstripped 
   version in
     <project>/obj/local/<abi>/

   where <abi> is either armeabi, armeabi-v7a, armabi-v8a, or x86 depending on your app.

   It then copies and strips the library, placing the new, stripped 
   copy in the location that will be packaged into the .apk file:
     <project>/libs/<abi>/ 

   Make sure that you finalize the version stored in the 
   <project>/obj/local/<abi>/ directory and then copy the finalized 
   version into the <project>/libs/<abi>/ directory. The
   stripped version in the libs directory cannot be finalized.

3. If the pre-finalized library was delivered with a .key file, it
   indicates that the finalization data (.fin) file is encrypted. The .key
   file must be in the same directory as the .fin file when you
   run the library through the finalizer. The finalizer
   will use that file  to de-crypt the finalization data (.fin) file.

_ _ _ _ _ _ _ _ _ _ _
For Apple iOS Targets

Use this procedure to set up a new Xcode project, to link in a partially
protected library with the current finalizer.

NOTE: For instructions for upgrading an existing Xcode project to use the 
current finalizer, see the last procedure in this README (following 
the list of finalizer options). 


After receiving a partially protected static library (.a) and .fin
file(s) from your vendor, do the following:
  1. Create the Xcode project for the application to which the
     library will be linked.

  2. Make sure that the partially protected library and the
     finalization (.fin) file(s) are in the same directory.
       IMPORTANT NOTE: If the .a file is a universal binary with
       multiple architectures, there will be a .fin file for each
       architecture. Make sure all files received from your vendor
       are in the same directory. Also, in such cases, the finalizer
       expects the .fin files to be named in the following format:
           <static_lib_name>-<architecture>.fin
       where <static_lib_name> is the full name of the .a file and
       <architecture> is the target architecture (e.g. "armv7" or "arm64")

  3. Import the partially protected library file into the Xcode
     project.
     Make sure the library is a dependency for the application.

  4. Enable generation of a map file by setting the "Write Link
     Map File" setting to "Yes" in the "Build Settings" tab for the target
     in the Xcode project.

  5. In the Xcode project Build Phases tab for the target application, add a
     "New Run Script Phase" and rename it to "Finalize Protection"

     Leave the shell as the default "/bin/sh"
     Add the following as the command to run:

        <finalizer_kit_path>/Xcode/xcode-finalize-protection.py  -prefinalized-library <lib>   

     Where:
       <finalizer_kit_path> is the path to the Finalizer installation
       <lib> is the path to the partially protected library

     If you have multiple pre-finalized libraries, specify the flag
     for each library; for example:
     -prefinalized-library <lib1> -prefinalized-library <lib2>

  6. If the library will be included in a dynamic framework, add the 
     following in the "Finalize Protection" Build Phase:
       -bundle-id <identifier>
     
     The value for <identifier> can be found on the General tab of 
     the target dynamic framework. Alternatively, you can extract 
     the identifier from CFBundleIdentifier in the Info.plist file.
 
  7. If the library was protected with debug-mode protection, set
     one of the following in "Finalize Protection" Build Phase
     to generate debug information at runtime:
         -finalizer-debug
         -finalizer-debug-verbose
     NOTE: The -finalizer-debug flag turns on default level, runtime
     debug information. The -finalizer-debug-verbose flag turns on
     verbose runtime debug information.

  8. To obtain verbose information about the operations of the 
     finalizer, add the following in the "Finalize Protection" Build Phase:
         -finalizer-verbose

  9. Run the Xcode build command.

IMPORTANT NOTE:
1. If the pre-finalized library was delivered with a .key file, it
   indicates that the finalization data (.fin) file is encrypted. The .key
   file must be in the same directory as the .fin file when you
   run the library through the finalizer. The finalizer
   will use that file  to de-crypt the finalization data (.fin) file.

_____________________________________________________________
The Finalizer Command Line Arguments

The command line arguments are:

-strip-cmd <path_to_strip_command> identifies the location of a strip
command. This argument must be included if the target is an Android
application. (For Android, see also The NOTES at the end of the Android
instructions.)

<binary_file_name> is the name of the binary file output by the linker.

<map_file_name> is the name of the binary file's associated map file.

<fin_file_name> is the finalization data (.fin) file provided by your
vendor. This file was generated when the static library was processed
during the first stage of protection. The version of the .fin file must
be a version that is supported by the Finalizer. (See the information
at the top of this README.) 
If multiple protected static libraries are to be linked to the
application, there will be multiple finalization data files, one
for each library. Use a space as a separator for the names in such
cases.

-bundle-id <identifier>, where <identifier> is the CFBundleIdentifier
as specified in the Info.plist file. This is iOS only. 

-o <output_binary_name> specifies the name you want to assign to the
binary file. The name defaults to <binary_file>.finalized if this
argument is not set.

options are:

     -disable-strip, which disables stripping of symbols

     -patch <symbol_name> <byte_sequence>, which patches the binary
      with the specified <byte_sequence> beginning at the address
      represented by <symbol_name>. You can include multiple -patch
      arguments if you want to patch multiple ranges. Use this
      argument only if you want to test the protection. Patching a
      protected symbol will trigger the protection to fire.

     -quiet, which prints nothing during processing except error
      messages

     -v, which prints verbose messages during finalization processing
      Note: If you are using Xcode, do not use -v. Instead, specify the 
      -finalizer-verbose command line parameter to xcode-finalize-protection.py.

     -help, which prints this usage information, but does not
      process the files

     -runtime-debug-data <file_path> identifies the runtime location
      of the debug data file. Include this argument only if the
      library was protected using debug-mode protection (during the
      first stage of protection) and only if the binary will run on a
      platform that is different from the platform on which
      protection was applied.
      You must work with the library vendor to use this argument.
      For iOS: This argument is not needed. The information is set
               automatically when you specify either -finalizer-debug flag
               command line parameter to xcode-finalize-protection.py.
      
     -suppress-api-26-warning will, when targeting Android, suppress
      warnings when Repair or Damage guards require runtime modification
      of code. Android API level 26 or higher will no longer support
      self modifying code. If you are just targeting Android API levels
      less than 26, you may want to suppress the warning.

 _ _ _ _ _ _ _ _ _ _ _
Output of the Finalizer
The finalizer utility outputs a protected binary file. If the finalizer 
stops with an error indicating insufficient space for a Guard, 
a size (.sz) configuration file is also output.
To resolve that error, contact your vendor. The size configuration file
must be provided to the library vendor so that the vendor can re-protect
the library, using the size configuration file as input. 
 
If the library was protected using debug-mode protection, the finalizer
produces an additional file, a debug data (.dbg) file, named
<output_binary_file>.dbg. This file must be accessible at runtime to
the application. It provides information about the protected code that
the protection uses at runtime to determine whether the code has been
changed. Depending on the target platform, the -runtime-debug-data
argument may be required on the finalizer command line when this file
is expected to be produced.
Work with your library vendor to use this file and that argument.

IMPORTANT NOTE: If you complete the protection and the finalizer
produces a .dbg file in addition to the binary, it
indicates that the linked library is protected by debug-mode
protections. Releasing a binary with debug-mode protections is NOT
recommended. Contact your vendor.

______________________________________
Updating an Existing Project

Use this procedure to update an existing project:

1. Open the project in Xcode. 
2. At the Target level, remove the following flags from Other Linker Flags: 
    o -finalize
    o -prefinalized-library <lib> where <lib> is the path to the partially
       protected library
    o -finalized-product, if present
    o -bundle-id <identifier>, if present
    o Any other finalization flags mentioned in this document.
3. In the Xcode project Build Phases tab for the target application, add a
     "New Run Script Phase" and rename it to "Finalize Protection"

    Leave the shell as the default "/bin/sh"
    Add the following as the command to run:

       <finalizer_kit_path>/Xcode/xcode-finalize-protection.py  -prefinalized-library <lib>   

    Where:
       <finalizer_kit_path> is the path to the Finalizer installation
       <lib> is the path to the partially protected library

    If you have multiple pre-finalized libraries, specify the flag
    for each library; for example:
    -prefinalized-library <lib1> -prefinalized-library <lib2>
4. If the library is included in a dynamic framework, add the following flag
    to the xcode-finalize-protection.py invocation in the "Finalize Protection" Build Phase:
       -bundle-id <identifier>
5. If the library was built in debug mode, add a debug flag to the 
   xcode-finalize-protection.py invocation in the "Finalize Protection" Build Phase. The debug flags are:
    o -finalizer-debug
    o -finalizer-debug-verbose
6. Run the Xcode build command.
     

This product contains LLVM, licensed under the University of Illinois/NCSA 
Open Source License, which can be found at 
http://www.opensource.org/licenses/UoI-NCSA.php
Also see http://llvm.org/docs/DeveloperPolicy.html#license