#!/bin/bash
#
# This script installs the Xcode finalizer wrapper scripts into
# a specified Apple Developer Tools location
#
function errorexit {
   echo "Error: Finalizer Xcode wrappers failed to (un)install."
}
trap errorexit EXIT
set -o errexit

# avoid "dyld: DYLD_ environment variables being ignored because main executable (/usr/bin/sudo) is setuid or setgid"
unset DYLD_LIBRARY_PATH

script_name=$(basename "$0")
finalizer_wrapper_script="xcode-finalizer-wrapper.sh"
action="install"
install_to=""
# optionally wrap the commands with sudo
opt_sudo=""

#Print usage message
function usage {
   echo "usage: $script_name [-uninstall] [path_to_developer_tools]"
   trap - exit
   exit 1
}

#Print an error message and exit
function mexit {
   echo "$1"
   echo "Xcode finalizer wrappers ${action} failed."
   trap - exit
   exit 1
}   

#Callback for error handling 
function on_error {
   mexit ""
}

# Check permissions and update $optional_sudo appropriately
function check_permissions {
   if [ ! -w "${xcode_bin_dir}" -o ! -r "${xcode_bin_dir}" -o ! -x "${xcode_bin_dir}" ]; then
      echo "Xcode was installed with superuser privledges. Installation will proceed using sudo."
      echo "You may be asked for your sudo password."
      sudo -v
      opt_sudo="sudo"
   fi
}

#Parse commandline arguments
mode_found_count=0
for arg in "$@"
do
    if [ "${arg}" = "-uninstall" ]
    then
        action="uninstall"
        ((mode_found_count++))
    elif [ "${arg}" = "-install" ]
    then
        action="install"
        ((mode_found_count++))
    elif [ ${arg:0:1} = "-" ]
    then
        usage
    elif [ -z "${install_to}" ]
    then
        install_to="${arg}"
    else
        usage
    fi
done

#Basic sanity check of arguments
if [ ${mode_found_count} -gt  1 ]
then
    usage
fi

if [ ${action} = "install" ]
then
  echo
  echo "---------------------------------------------------------------"
  echo ""
  echo "WARNING: install-xcode-finalizer-wrapper.sh has been deprecated."
  echo "Please uninstall the wrapper using \"${script_name} -uninstall\""
  echo "and instead configure the Xcode project with a Run Script Build Phase "
  echo "to run the xcode-finalize-protection.py script after linking the binary. "
  echo "See the finalizer documentation for more details."
  echo ""
  echo "WARNING: Xcode iOS builds are dependent on this finalizer installation."
  echo "If you remove the finalizer, be sure to re-run this script with the"
  echo "-uninstall flag, ie:"
  echo 
  echo "   ./${script_name} -uninstall "
  echo "---------------------------------------------------------------"
  echo
fi

# If install_to wasn't set on command line, default to xcode-select'd version
# Prompt user to confirm.
if [ -z "${install_to}" ] 
then
    install_to=`xcode-select -print-path`

    if [ ${action} = "install" ]
    then
        echo
        echo "To install to a different location:"
        echo "   ${script_name} path_to_developer_tools"
        echo
        read -p "Install finalizer integration to ${install_to} (y/n)? "
    else
        echo
        echo "To uninstall from a different location:"
        echo "   ${script_name} -uninstall path_to_developer_tools"
        echo
        read -p "Uninstall finalizer integration from ${install_to} (y/n)? "
    fi

    if [ "$REPLY" != "y" ]
    then
        mexit "User cancelled."
    fi
fi

#Strip trailing slashes from install directory
install_to="${install_to%/}"

#Append /Contents/Developer if needed
if [[ "${install_to}" == *Xcode*.app ]]
then
    install_to="${install_to}/Contents/Developer"
fi

finalizer_script_dir="$(dirname "$0")"
finalizer_bin_dir="${finalizer_script_dir}/../../"
if [[ ! -x "${finalizer_bin_dir}/finalizer" ]] \
    && [ ${action} = "install" ]
then
    echo "Didn't find valid finalizer installation."
    echo "Was this script moved?"
    echo "Doing nothing."
    trap - EXIT
    exit
fi

#Find absolute path to finalizer bin directory
pushd . >/dev/null
cd "${finalizer_bin_dir}"
absolute_finalizer_bin_dir="$(pwd)"
popd >/dev/null

# Paths which contain ".app" have a different layout than the old /Developer
# versions of Xcode, so choose accordingly. 
if [[ "${install_to}" == *Xcode*.app* ]]
then
    developer_bin_dir="${install_to}/Platforms/iPhoneOS.platform/Developer/usr/bin"
    xcode_bin_dir="${install_to}/Toolchains/XcodeDefault.xctoolchain/usr/bin"
else
    developer_bin_dir="${install_to}/Platforms/iPhoneOS.platform/Developer/usr/bin"
    xcode_bin_dir="${developer_bin_dir}"
fi

# Make sure we have an Xcode at the computed path
if [ ! -d "${developer_bin_dir}" ]
then
    echo "Didn't find a valid Xcode for iOS installation at '${install_to}'"
    echo "Doing nothing."
    trap - EXIT
    exit
fi

# For every symlink in the cwd that points to old_target, swap
# the link to point to new_target.  Its OK to use this after
# the referenced old_target file has been deleted. This is intended
# to fix the broken link
#
# arg 1: old_target
# arg 2: new_target
function update_symlinks {
  old_target=$1
  new_target=$2
  #Find all symlinks
  symlinks=`${opt_sudo} find . -type l -maxdepth 1`

  #Iterate over found links, change the link if it points to old_target 
  for symlink in ${symlinks}
  do
    link_target=`${opt_sudo} readlink "${symlink}"`
    if [[ ${link_target} == ${old_target} ]]
    then
      ${opt_sudo} ln -sf "${new_target}" "${symlink}"
    fi
  done
}

function install_clang_wrapper {
  replaced="clang"
  original="original-clang"

  #The original clang is the actual executable, and clang++ is a symlink,
  #so we'll move the original instead of linking it.  
  if [ ! -L "${replaced}" ]; then
    ${opt_sudo} rm "${replaced}++"
    ${opt_sudo} mv "${replaced}" "${original}"
  fi 

  #create a new clang++ symlink 
  if [ -a "${original}" ]; then
    ${opt_sudo} ln -sf "${original}" "${original}++"
    ${opt_sudo} ln -sf "${absolute_finalizer_bin_dir}/Xcode/deprecated/${finalizer_wrapper_script}" "${replaced}"
    ${opt_sudo} ln -sf "${absolute_finalizer_bin_dir}/Xcode/deprecated/${finalizer_wrapper_script}" "${replaced}++"
  fi 

  #Update any other symbolic links that were just broken.
  update_symlinks "${replaced}" "${original}"
  update_symlinks "${replaced}++" "${original}++"
}

function uninstall_clang_wrapper {
  replaced="clang"
  original="original-clang"
   
  #Remove the symlinks we have created.
  if [ -L "${replaced}" ]; then
    ${opt_sudo} rm "${replaced}"
    ${opt_sudo} rm "${replaced}++"
    ${opt_sudo} rm "${original}++"
    ${opt_sudo} mv "${original}" "${replaced}"
    ${opt_sudo} ln -sf "${replaced}" "${replaced}++"
  fi 

  #Find and fix any other symbolic links that were just broken.
  update_symlinks "${original}" "${replaced}"
  update_symlinks "${original}++" "${replaced}++"
}

# From here, handle all errors with on_error
trap on_error ERR

check_permissions "${xcode_bin_dir}"

pushd . >/dev/null

# Install/uninstall clang and clang++ wrapper 
cd "${xcode_bin_dir}"
${action}_clang_wrapper

popd >/dev/null
echo "Xcode finalizer wrappers ${action}ed successfully."
trap - EXIT
exit 0
