#!/bin/bash

# this flag indicates that we will perform a custom step
readonly finalizer_link_flag="-finalize"

uses_finalizer=0
for arg in "$@"; do
  if [[ $arg == $finalizer_link_flag ]]; then
    uses_finalizer=1
    break
  fi
done

if [[ $uses_finalizer -eq 0 ]]; then
  # the quotes around $@ are important. They quote all of the elements of $@
  # http://www.gnu.org/software/bash/manual/html_node/Special-Parameters.html
  "`dirname "$0"`/original-`basename "$0"`" "$@"
  exit $?
fi

function echo_note {
    echo "Note: $1"
}

function echo_warn {
    echo "Warning: $1"
}

function echo_error {
    echo "Error: $1"
}

function run_cmd {
  local desc=$1
  local cmd="${!2}"
  local args=("${!3}")

  local info="${desc} "
  echo_note "${info}"
  echo "<Finalizer Command> ${cmd} ${args[@]}"

  "${cmd}" "${args[@]}" 2>&1
  cmd_err=$?

  if [[ ${cmd_err} != 0 ]]
  then
    echo_error "${desc} Failed"
    set -e
    exit ${cmd_err}
  fi

}

function usage {
    echo_error "$1"
    echo_note  "Finalization requires the following flags:"
    echo_note  "     -finalize"
    echo_note  "     -prefinalized-library"
    echo_note  "You may copy and paste the following into \"Other Linker Flags\" of Xcode Linker settings:"
    echo_note  "     -finalize -prefinalized-library /path/to/prefinalized/library.a"
    echo_note  "Optional flags:"
    echo_note  "     -finalizer-verbose: Prints verbose finalization information"
    exit 1
}

#These argument names are handled specially by this script
readonly prefinalized_file_flag="-prefinalized-library"
readonly finalized_product_flag="-finalized-product"
readonly finalizer_debug_flag="-finalizer-debug"
readonly finalizer_disable_strip_flag="-finalizer-disable-strip"
readonly finalizer_strip_cmd_flag="-finalizer-strip-cmd"
readonly finalizer_quiet_flag="-finalizer-quiet"
readonly finalizer_verbose_flag="-finalizer-verbose"
readonly finalizer_debug_verbose_flag="-finalizer-debug-verbose"
readonly finalizer_original_tool_flag="-original-tool"
readonly finalizer_more_opts_flag="-Wfin"
readonly move="mv"

#Default values
finalizer_link_flag_found="false"
finalizer_map_file_found="false"
finalizer_map_file=""
output_file=""
finalizer_debug="false"
finalizer_debug_verbose="false"
current_arch=""
built_product=""
intermediate_dir=""
finalized_executable_dir=""
linker=""

#Make a copy of the original args, since the next loop will eat them
declare -a original_args
i=0
for arg in "$@"
do
    original_args[$i]="$arg"
    ((i++))
done

#Search all the arguments, looking for special finalizer flags
#filtered_args will be a copy of the original input arguments
declare -a filtered_args
declare -i filtered_index
filtered_index=0
declare -a prefinalized_files
declare -i prefinalized_files_index
prefinalized_files_index=0
declare -a tune_size_file_move
declare -i tune_size_file_move_index
tune_size_file_move_index=0
declare -a finalizer_args
declare -i finalizer_index
finalizer_index=0
declare -a prefin_file_move
declare -i prefin_file_move_index
prefin_file_move_index=0

while [ $# -gt 0 ]
do
    case "$1" in
    ${finalizer_original_tool_flag} )
        shift
        linker="$1"
        ;;
    ${finalizer_link_flag} )
        finalizer_link_flag_found="true"
        #specifically not adding -finalize to filtered_args
        ;;
    ${prefinalized_file_flag} )
        shift
        prefinalized_files[$prefinalized_files_index]="$1"
        ((prefinalized_files_index++))
        ;;
    ${finalizer_debug_flag} )
        finalizer_debug="true"
        ;;
    ${finalizer_debug_verbose_flag} )
        finalizer_debug="true"
        finalizer_debug_verbose="true"
        ;;
    ${finalized_product_flag} )
        shift
        built_product="$1"
        ;;
    ${finalizer_disable_strip_flag} )
        finalizer_args[$finalizer_index]="-disable-strip"
        ((finalizer_index++))
        ;;
    ${finalizer_strip_cmd_flag} )
        shift
        finalizer_args[$finalizer_index]="-strip-cmd"
        ((finalizer_index++))
        finalizer_args[$finalizer_index]="$1"
        ((finalizer_index++))
        ;;
    ${finalizer_quiet_flag} )
        finalizer_args[$finalizer_index]="-quiet"
        ((finalizer_index++))
        ;;
    ${finalizer_verbose_flag} )
        finalizer_args[$finalizer_index]="-v"
        ((finalizer_index++))
        ;;
	${finalizer_more_opts_flag},* )
        OIFS=$IFS # dont clobber the old IFS
        IFS=","
        read -ra fin_opts <<< "$1" # split the -Wfin,a,b,c into an array
        unset fin_opts[0] # delete the -Wfin
        # add the options to the finalizer options
		for fin_opt in "${fin_opts[@]}"; do
			finalizer_args[$finalizer_index]=$fin_opt
			((finalizer_index++))
        done
        IFS=$OIFS
        ;;
    "-arch" )
        shift
        #Save the current architecture
        current_arch="$1"
        filtered_args[$filtered_index]="-arch"
        ((filtered_index++))
        filtered_args[$filtered_index]="$1"
        ((filtered_index++))
        ;;
    "-o" )
        shift
        #Save the current architecture
        finalizer_outputfile="$1"
        filtered_args[$filtered_index]="-o"
        ((filtered_index++))
        filtered_args[$filtered_index]="$1"
        ((filtered_index++))
        output_file="$1"
        ;;
    "-Xlinker" )
        filtered_args[$filtered_index]="-Xlinker"
        ((filtered_index++))
        shift

        filtered_args[$filtered_index]="$1"
        ((filtered_index++))

        if [ "$1" = "-map" ]
        then
            finalizer_map_file_found="true"
            shift

            filtered_args[$filtered_index]="$1"  #-Xlinker
            ((filtered_index++))
            shift

            filtered_args[$filtered_index]="$1"  #LinkMap filename
            ((filtered_index++))

            finalizer_map_file="$1"
        fi

        ;;
    "-filelist" )
        filtered_args[$filtered_index]="-filelist"
        ((filtered_index++))
        shift
        filtered_args[$filtered_index]="$1"
        ((filtered_index++))
        intermediate_dir="$(dirname "$1")"
        ;;
    * )
        filtered_args[$filtered_index]="$1"
        ((filtered_index++))
        ;;
    esac
    shift
done

if [[ ${linker} == "" ]]
then
    #Find the directory and name of called program, ie this
    #script.  This will be used to call the original linker.
    readonly full_name="$0"
    readonly directory="$(dirname  "${full_name}")"
    readonly called_program="$(basename "${full_name}")"
    readonly prefix="original"


    #This is the exec that will be called after processing
    #the arguments.  Defaults to the compiler, either
    #   original-llvm-gcc-4.2
    #   original-llvm-g++-4.2
    #If the -finalize flag is found, finalize and link
    linker="${directory}"/${prefix}-${called_program}
fi


#Modify the filtered arguments list for finalization

if [[ ${finalizer_link_flag_found} == "true" ]]
then

    #Built components
    finalized_executable="$(basename "${finalizer_outputfile}")"
    finalized_executable_dir="$(dirname "${finalizer_outputfile}")"
    debug_info_file_arch="${finalized_executable}-${current_arch}.dbg"

    if [[ "${intermediate_dir}" == "" ]]
    then
        # No intermediate dir is known. Use /tmp to prevent
        # intermediate files from being placed in the .app directory.
        intermediate_dir="/tmp/finalizer/${finalized_executable}/${current_arch}"

        # Create the directory if it does not exist
        mkdir -p "$intermediate_dir"
    fi

    #Mapfile Generation Required
    if [[ "${finalizer_map_file_found}" == "false" ]]
    then
        # For Xamarin we need to create the map file based on the directory of the outputfile
        # might as well do this for Xcode if the user did not set the setting to true.
        finalizer_map_file="${output_file}.map"
        filtered_args[$filtered_index]="-Xlinker"
        ((filtered_index++))
        filtered_args[$filtered_index]="-map"
        ((filtered_index++))
        filtered_args[$filtered_index]="-Xlinker"
        ((filtered_index++))
        filtered_args[$filtered_index]="${finalizer_map_file}"
        ((filtered_index++))
    fi

    #Finalizer components
    finalizer_bin=""
    if [[ "$(basename "$0" )" == "xcode-finalizer-wrapper.sh" ]]
    then
        finalizer_bin="$(dirname "$0")/.."
    else
        finalizer_script_dir="$(dirname "$(readlink "$0")")"
        finalizer_bin="${finalizer_script_dir}/../.."
    fi

    env_script="${finalizer_bin}"/setenv.sh
    finalizer="${finalizer_bin}/finalizer"

    if [[ ! -a "$env_script" ]]
    then
        echo_error "Couldn't find finalizer components in '${finalizer_bin}'."
        echo_note  "Please check finalizer installation."
        exit 1
    fi

    if [[ "${finalizer_debug}" == "true" ]]
    then

        debug_suffix=""

        if [[ ${finalizer_debug_verbose} == "true" ]]
        then
            debug_suffix=".v"
    	fi

        finalizer_args[$finalizer_index]="-runtime-debug-data"
        ((finalizer_index++))
        finalizer_args[$finalizer_index]="${finalized_executable}.app/${debug_info_file_arch}${debug_suffix}"
        ((finalizer_index++))
    fi

    finalizer_args[$finalizer_index]="-bundle-directory"
    ((finalizer_index++))
    finalizer_args[$finalizer_index]="$(dirname "$built_product")"
    ((finalizer_index++))

    finalizer_args[$finalizer_index]="-o"
    ((finalizer_index++))
    finalizer_args[$finalizer_index]="${finalizer_outputfile}"
    ((finalizer_index++))

    #Binary
    finalizer_args[$finalizer_index]="${finalizer_outputfile}"
    ((finalizer_index++))

    #Linker Map File
    finalizer_args[$finalizer_index]="${finalizer_map_file}"
    ((finalizer_index++))

    #Finalizer file(s)
    if [ $prefinalized_files_index = 0 ]
    then
        usage "No finalizer input files found"
    fi

    #Tune size file
    tune_size_file_move[$tune_size_file_move_index]="${finalizer_outputfile}.sz"
    ((tune_size_file_move_index++))
    tune_size_file_move[$tune_size_file_move_index]="${intermediate_dir}"
    ((tune_size_file_move_index++))

    i=0
    for each_prefin_file in "${prefinalized_files[@]}"
    do
        fin_file="$each_prefin_file-$current_arch.fin"
        ((i++))

        finalizer_args[$finalizer_index]="$fin_file"
        ((finalizer_index++))
    done

    source "${env_script}"

fi

if [[ ${finalizer_link_flag_found} == "true" ]]
then

    debug_suffix=""

    if [[ ${finalizer_debug_verbose} == "true" ]]
    then
        debug_suffix=".v"
    fi

    run_cmd "Linking - " linker filtered_args[@]

    #Make a backup of prefin
    cp "${finalizer_outputfile}" "${finalizer_outputfile}.prefin"
    prefin_file_move[$prefin_file_move_index]="${finalizer_outputfile}.prefin"
    ((prefin_file_move_index++))
    prefin_file_move[$prefin_file_move_index]="${intermediate_dir}"
    ((prefin_file_move_index++))

    run_cmd "Finalizing - " finalizer finalizer_args[@]

    if [[ "${finalizer_debug}" == "true" ]]
    then
        echo_note "Moving debug file ${finalizer_outputfile}.dbg to location ${built_product}-${current_arch}.dbg${debug_suffix}"
        mv "${finalizer_outputfile}.dbg" "${built_product}-${current_arch}.dbg${debug_suffix}"
    fi


    if [[ "${finalized_executable_dir}" != "${intermediate_dir}" ]]
    then
        if [[ -f ${finalizer_outputfile}.sz ]]
        then
            run_cmd "Moving tune size files" move tune_size_file_move[@]
        fi
        run_cmd "Moving prefin backup file" move prefin_file_move[@]
    fi

else

    run_cmd " - " linker original_args[@]

fi
