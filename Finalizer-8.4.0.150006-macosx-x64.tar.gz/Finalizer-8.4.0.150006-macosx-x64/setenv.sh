#!/bin/bash
#
# This script does the following:
# 1. Point FINALIZER to the FINALIZER installation directory
# 2. Prepend PATH with $FINALIZER, if necessary

#########################################
#
# Source this script 
#
#########################################

# This script must be sourced
if [ "$BASH_SOURCE" == "$0" ]; then
    echo "Do not execute this script.  Source it, ie:"
    echo "   \$ source" $0
    exit 1;
fi

#########################################
#
# Set FINALIZER environment variable 
#
#########################################

# Go to Finalizer's installation directory
pushd . &>/dev/null
cd "`dirname \"${BASH_ARGV[0]}\"`"

# Make sure the directory is correct (check for the finalizer executable )
if [[ ! -e "`pwd`/finalizer" ]]; then
    echo "Unable to set up the Finalizer's execution environment"\
        "because this setenv.sh script has been moved away"\
        "from Finalizer's installation directory"
    return 1
fi

# Point FINALIZER to that directory unless it was set already
if [ "$FINALIZER" != "`pwd`" ]; then
    export FINALIZER=`pwd`  # use absolute path
    echo "Set FINALIZER to $FINALIZER"
fi

popd &>/dev/null

#########################################
#
# Set up PATH environment variable 
#
#########################################

# Add "$FINALIZER" to PATH (if not there yet)
if [ "`which finalizer`" != "$FINALIZER/finalizer" ]; then
    export PATH=$FINALIZER:$PATH
    echo "Added $FINALIZER to PATH"
fi
